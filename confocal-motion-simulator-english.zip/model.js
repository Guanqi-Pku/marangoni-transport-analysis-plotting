/* Confocal raster acquisition model. SI-derived units: µm, s, Hz.
   The interpolated-contour tracing routine is adapted from scikit-image; see THIRD_PARTY_NOTICES.txt. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.ConfocalModel = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const defaults = Object.freeze({ fov: 40, resolution: 256, lineHz: 200, duty: 0.8, betweenLineChannels: 0,
    bidirectional: false, slowDirection: 1, fastDirection: 1, mode: 'mixed', speed: 0.4,
    angle: 0, diffusion: 0.3, diffusionModel: 'water', temperatureC: 25, motion3D: true,
    initialZStd: 0.5, randomXY: true, diameter: 2.5, count: 9, psfXY: 0.45, psfZ: 1.2,
    noise: true, photons: 150, background: 2, readNoise: 0.8, threshold: 0.35,
    seed: 42, dwellSamples: 1 });

  function rng(seed) {
    let a = seed >>> 0, spare;
    const uniform = () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ t >>> 15, t | 1);
      t ^= t + Math.imul(t ^ t >>> 7, t | 61); return ((t ^ t >>> 14) >>> 0) / 4294967296; };
    const normal = () => { if (spare !== undefined) { const s = spare; spare = undefined; return s; }
      const r = Math.sqrt(-2 * Math.log(Math.max(1e-12, uniform()))), t = 2 * Math.PI * uniform();
      spare = r * Math.sin(t); return r * Math.cos(t); };
    return { uniform, normal };
  }
  function timing(p) {
    const n = p.resolution, betweenLineChannels = Math.max(0, Math.min(2, Math.round(Number(p.betweenLineChannels) || 0)));
    const channelCount = betweenLineChannels + 1, lineTime = 1 / p.lineHz, targetLineTime = channelCount * lineTime;
    const frameTime = n * targetLineTime, dwell = p.duty * lineTime / n;
    return { betweenLineChannels, channelCount, lineTime, targetLineTime, frameTime, fps: 1 / frameTime, dwell,
      pixelSize: p.fov / n, fastSpeed: p.fov * p.lineHz / p.duty, slowSpeed: p.fov / frameTime,
      lastTargetSampleTime: (n - 1) * targetLineTime + (n - .5 / (p.dwellSamples || 1)) * dwell };
  }
  // Each target line owns a cycle of target channel + zero, one or two other
  // channels. There is no additional switching overhead. Bidirectional scanning
  // alternates by TARGET row, independently of the intervening channel slots.
  function acquisitionPhase(p, time) {
    const t = timing(p), n = p.resolution, at = Math.max(0, Math.min(t.frameTime, Number(time) || 0));
    const complete = at >= t.frameTime, targetRow = Math.min(n - 1, Math.floor(at / t.targetLineTime + 1e-12));
    const cycleTime = complete ? t.targetLineTime : Math.max(0, at - targetRow * t.targetLineTime);
    const slotIndex = complete ? t.channelCount - 1 : Math.min(t.channelCount - 1, Math.floor(cycleTime / t.lineTime + 1e-12));
    const slotTime = complete ? t.lineTime : Math.max(0, cycleTime - slotIndex * t.lineTime);
    const slot = complete ? 'complete' : slotIndex === 0 ? 'target' : 'other';
    const scanning = !complete && slotTime + t.lineTime * 1e-12 < p.duty * t.lineTime;
    const targetActive = slot === 'target' && scanning;
    const completedRows = complete ? n : targetRow + (slot !== 'target' || !scanning ? 1 : 0);
    const pixelsInRow = targetActive ? Math.min(n - 1, Math.max(0, Math.floor(slotTime / t.dwell + 1e-10))) : 0;
    return { t: at, complete, targetRow, rowIndex: p.slowDirection === -1 ? n - 1 - targetRow : targetRow,
      slotIndex, slot, slotTime, scanning, targetActive, completedRows, pixelsInRow,
      acquiredPixels: completedRows * n + pixelsInRow,
      fastDirection: p.fastDirection * (p.bidirectional && targetRow % 2 === 1 ? -1 : 1),
      phase: complete ? 'complete' : slot + (scanning ? '-scan' : '-turnaround') };
  }
  function velocity(p) {
    const v = p.mode === 'brownian' ? 0 : p.speed, a = p.angle * Math.PI / 180;
    return [v * Math.cos(a), v * Math.sin(a)];
  }
  // Empirical viscosity of liquid water (Pa s); the UI uses its 0–80 °C range.
  function waterViscosity(temperatureC = 25) {
    const kelvin = Number(temperatureC) + 273.15;
    if (!Number.isFinite(kelvin) || kelvin <= 140) throw new RangeError('Invalid water temperature');
    return 2.414e-5 * 10 ** (247.8 / (kelvin - 140));
  }
  // Hydrodynamic sphere diameter in µm; the SI result m²/s is converted to µm²/s.
  function stokesEinstein(diameter, temperatureC = 25) {
    if (!(diameter > 0)) throw new RangeError('Particle diameter must be positive');
    return 1.380649e-23 * (Number(temperatureC) + 273.15) /
      (3 * Math.PI * waterViscosity(temperatureC) * diameter * 1e-6) * 1e12;
  }
  function diffusion(p) {
    if (p.mode === 'directed') return 0;
    return p.diffusionModel === 'water' ? stokesEinstein(p.diameter, p.temperatureC ?? 25) : Math.max(0, Number(p.diffusion) || 0);
  }
  function erf(x) {
    const s = x < 0 ? -1 : 1; x = Math.abs(x); const t = 1 / (1 + 0.3275911 * x);
    return s * (1 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * Math.exp(-x * x));
  }
  const profileCache = new Map();
  // Uniformly fluorescent sphere integrated against a separable 3-D Gaussian PSF.
  // At lateral source radius rho, the axial integral is
  // 1/2 [erf((sqrt(R²-rho²)+z)/(sqrt(2)sz)) + erf((sqrt(R²-rho²)-z)/(sqrt(2)sz))].
  // Gaussian lateral convolution follows on a Cartesian quadrature grid. Symmetry
  // and precomputed kernels keep the complete radius–|z| lookup responsive.
  function makeProfile(p) {
    const key = [p.diameter, p.psfXY, p.psfZ, p.threshold].join('/');
    if (profileCache.has(key)) return profileCache.get(key);
    const R = p.diameter / 2, s = p.psfXY / 2.354820045, sz = p.psfZ / 2.354820045;
    const extent = R + 4.5 * s;
    const half = Math.min(512, Math.max(96, Math.ceil(extent / Math.min(R / 40, s / 3))));
    const dx = extent / half, sourceHalf = Math.floor(R / dx), axialScale = Math.SQRT2 * sz;
    const zExtent = R + 4.5 * sz;
    const zSteps = Math.min(256, Math.max(24, Math.ceil(zExtent / Math.min(sz / 8, R / 16))));
    const dz = zExtent / zSteps, axialCells = [], lateralKernels = [];
    const g = i => Math.exp(-0.5 * (i * dx / s) ** 2);
    for (let i = 0; i <= sourceHalf; i++) {
      const row = [];
      for (let j = 0; j <= sourceHalf; j++) {
        const r2 = (i * i + j * j) * dx * dx;
        if (r2 >= R * R) break;
        row.push([Math.sqrt(R * R - r2), g(j) * (j === 0 ? 1 : 2)]);
      }
      axialCells.push(row);
    }
    for (let i = 0; i <= half; i++) {
      const row = [];
      for (let j = 0; j <= sourceHalf; j++) {
        // Preserve the previous finite 4.5 sigma lateral integration extent.
        const weight = (Math.abs(i - j) <= half ? g(i - j) : 0) + (j > 0 && i + j <= half ? g(i + j) : 0);
        if (weight > 1e-13) row.push([j, weight]);
      }
      lateralKernels.push(row);
    }
    const planes = [];
    for (let zi = 0; zi <= zSteps; zi++) {
      const z = zi * dz, h = new Float64Array(sourceHalf + 1), values = new Float64Array(half + 1);
      for (let i = 0; i <= sourceHalf; i++) {
        for (const [height, weight] of axialCells[i]) {
          const axial = zi === 0 ? erf(height / axialScale) :
            Math.max(0, (erf((height + z) / axialScale) + erf((height - z) / axialScale)) / 2);
          h[i] += weight * axial;
        }
      }
      for (let i = 0; i <= half; i++) {
        for (const [j, weight] of lateralKernels[i]) values[i] += h[j] * weight;
      }
      planes.push(values);
    }
    // Common normalization is essential: no individual z plane is rebrightened.
    const peak = planes[0][0];
    for (const plane of planes) for (let i = 0; i < plane.length; i++) plane[i] /= peak;
    const values = planes[0];
    let sumR = 0, sumR3 = 0, rCut = 0;
    for (let i = 0; i <= half; i++) {
      const r = i * dx;
      if (values[i] >= p.threshold) { sumR += r * values[i] * dx; sumR3 += r ** 3 * values[i] * dx; rCut = r; }
    }
    const profile = { values, planes, dx, extent, dz, zExtent, normalizationPeak: peak,
      baselineDiameter: 4 * Math.sqrt(sumR3 / (2 * sumR)), baselineArea: Math.PI * (rCut + dx / 2) ** 2 };
    // Bound memory during parameter sweeps; geometry-identical frames reuse arrays.
    if (profileCache.size >= 12) profileCache.delete(profileCache.keys().next().value);
    profileCache.set(key, profile);
    return profile;
  }
  function sampleProfile(profile, distance, z = 0) {
    const i = Math.max(0, distance) / profile.dx, j = Math.floor(i);
    if (j >= profile.values.length - 1) return 0;
    const f = i - j;
    if (!profile.planes || z === 0) return profile.values[j] * (1 - f) + profile.values[j + 1] * f;
    const zi = Math.abs(z) / profile.dz, k = Math.floor(zi);
    if (k >= profile.planes.length - 1) return 0;
    const g = zi - k, a = profile.planes[k], b = profile.planes[k + 1];
    return (a[j] * (1 - f) + a[j + 1] * f) * (1 - g) + (b[j] * (1 - f) + b[j + 1] * f) * g;
  }
  function createParticles(p) {
    const random = rng(p.seed), cols = Math.ceil(Math.sqrt(p.count)), rows = Math.ceil(p.count / cols);
    // Separate axial random stream preserves paired xy realizations in 2-D/3-D.
    const axialRandom = rng(p.seed + 0x9E3779B9);
    const particles = [];
    for (let k = 0; k < p.count; k++) {
      let x, y;
      if (p.randomXY) {
        const margin = Math.min(p.fov * .35, Math.max(p.fov * .06, p.diameter / 2 + p.psfXY));
        let bestDistance = -1;
        for (let attempt = 0; attempt < 256; attempt++) {
          const cx = margin + random.uniform() * (p.fov - 2 * margin), cy = margin + random.uniform() * (p.fov - 2 * margin);
          const nearest = particles.reduce((m, q) => Math.min(m, (cx - q.x) ** 2 + (cy - q.y) ** 2), Infinity);
          if (nearest > bestDistance) { x = cx; y = cy; bestDistance = nearest; }
          if (nearest >= (p.diameter + p.psfXY) ** 2) break;
        }
      } else {
        const gx = cols === 1 ? 0.45 : 0.17 + (k % cols) * 0.59 / (cols - 1);
        const gy = rows === 1 ? 0.42 : 0.15 + Math.floor(k / cols) * 0.57 / (rows - 1);
        x = (gx + (random.uniform() - .5) * .025) * p.fov;
        y = (gy + (random.uniform() - .5) * .025) * p.fov;
      }
      particles.push({ id: k + 1, x, y, z: p.motion3D ? Math.max(0, p.initialZStd || 0) * axialRandom.normal() : 0 });
    }
    return particles;
  }
  function eigen(a, b, c) {
    const t = Math.sqrt((a - c) ** 2 + 4 * b * b), l1 = Math.max(0, (a + c + t) / 2), l2 = Math.max(0, (a + c - t) / 2);
    return { l1, l2, angle: Math.atan2(2 * b, a - c) / 2 * 180 / Math.PI };
  }
  function theoretical(p) {
    const t = timing(p), [vx, vy] = velocity(p), gx = p.fastDirection / t.fastSpeed, gy = p.slowDirection / t.slowSpeed;
    const a = 1 - vx * gx, b = -vx * gy, c = -vy * gx, d = 1 - vy * gy, det = a * d - b * c;
    if (Math.abs(det) < 1e-8) return { singular: true, determinant: det, beta: vy * gy, applicable: false };
    const aa = d / det, bb = -b / det, cc = -c / det, dd = a / det;
    const e = eigen(aa * aa + bb * bb, aa * cc + bb * dd, cc * cc + dd * dd);
    return { majorRatio: Math.sqrt(e.l1), minorRatio: Math.sqrt(e.l2), aspect: Math.sqrt(e.l1 / e.l2),
      areaRatio: 1 / Math.abs(det), angle: e.angle, beta: vy * gy, determinant: det,
      applicable: p.mode === 'directed' && !p.bidirectional && !p.motion3D, singular: false,
      reason: p.motion3D ? '3-D motion and defocus require the simulated image; affine axes are only a 2-D directed-motion reference.' :
        p.mode !== 'directed' ? 'Brownian motion has no fixed affine shape prediction.' : p.bidirectional ? 'Alternating scan directions do not share a single affine map.' : '' };
  }
  function emptyMoments(id) { return { id, w: 0, x: 0, y: 0, xx: 0, yy: 0, xy: 0, pixels: 0, edge: false, overlap: false }; }
  function addMoment(m, x, y, w, edge) {
    m.w += w; m.x += w * x; m.y += w * y; m.xx += w * x * x; m.yy += w * y * y; m.xy += w * x * y;
    m.pixels++; m.edge ||= edge;
  }
  function summarize(m, p, profile) {
    if (m.pixels < 5 || m.w <= 0) return { id: m.id, valid: false, missing: true, pixels: m.pixels, edge: m.edge, overlap: m.overlap };
    const x = m.x / m.w, y = m.y / m.w;
    const e = eigen(m.xx / m.w - x * x, m.xy / m.w - x * y, m.yy / m.w - y * y);
    const major = 4 * Math.sqrt(e.l1), minor = 4 * Math.sqrt(e.l2), area = m.pixels * (p.fov / p.resolution) ** 2;
    return { id: m.id, x, y, major, minor, aspect: major / Math.max(1e-10, minor), angle: e.angle,
      majorRatio: major / profile.baselineDiameter, minorRatio: minor / profile.baselineDiameter,
      area, areaError: area / profile.baselineArea - 1, edge: m.edge, overlap: m.overlap, pixels: m.pixels,
      missing: false, valid: !m.edge && !m.overlap };
  }
  // Per-particle BINARY area moments. Online accumulation avoids retaining any
  // per-ID image masks and keeps these independent of the intensity weights.
  function emptyContourMoments() { return { pixels: 0, x: 0, y: 0, xx: 0, xy: 0, yy: 0 }; }
  function addContourMoment(m, x, y) {
    m.pixels++;
    const dx = x - m.x, dy = y - m.y;
    m.x += dx / m.pixels; m.y += dy / m.pixels;
    m.xx += dx * (x - m.x); m.xy += dx * (y - m.y); m.yy += dy * (y - m.y);
  }
  function contourFromMoments(m, pixelSize) {
    if (!m.pixels) return null;
    // Each thresholded pixel is a uniformly filled square of side pixelSize,
    // adding its within-cell area variance pixelSize²/12 to both diagonals.
    const xx = m.xx / m.pixels + pixelSize ** 2 / 12, xy = m.xy / m.pixels;
    const yy = m.yy / m.pixels + pixelSize ** 2 / 12, e = eigen(xx, xy, yy);
    const major = 4 * Math.sqrt(e.l1), minor = 4 * Math.sqrt(e.l2), aspect = major / minor;
    // Image y increases downward; signed axial angle [-90,90] is clockwise +x.
    return { pixels: m.pixels, x: m.x, y: m.y, area: m.pixels * pixelSize ** 2,
      major, minor, aspect, angle: Math.abs(e.angle) < 1e-10 ? 0 : e.angle,
      orientationReliable: Number.isFinite(aspect) && aspect >= 1.05, covariance: { xx, xy, yy } };
  }
  // Independent helper for a single binary silhouette. Coordinates and axes
  // have the units of pixelSize (µm in the simulator); no size normalization.
  function binaryContourEllipse(mask, resolution, pixelSize = 1) {
    const m = emptyContourMoments();
    for (let i = 0; i < mask.length; i++) if (mask[i])
      addContourMoment(m, (i % resolution + .5) * pixelSize, (Math.floor(i / resolution) + .5) * pixelSize);
    return contourFromMoments(m, pixelSize);
  }
  // Linear marching squares, with the high-valued diagonal connected (the
  // skimage.find_contours fully_connected='high' convention). Only closed outer
  // polygons are eligible; holes do not subtract from outer-contour geometry.
  function intensityContourMetrics(image, width, height, level, pixelSize = 1, originX = 0, originY = 0) {
    const segments = [];
    const add = (a, b) => {
      if (a.point[0] === b.point[0] && a.point[1] === b.point[1]) return;
      segments.push([a.point, b.point]);
    };
    for (let y = 0; y < height - 1; y++) for (let x = 0; x < width - 1; x++) {
      const v = [image[y * width + x], image[y * width + x + 1], image[(y + 1) * width + x + 1], image[(y + 1) * width + x]];
      const code = (v[0] > level ? 1 : 0) | (v[1] > level ? 2 : 0) | (v[2] > level ? 4 : 0) | (v[3] > level ? 8 : 0);
      if (code === 0 || code === 15) continue;
      const points = [[x, y], [x + 1, y], [x + 1, y + 1], [x, y + 1]], edges = [[0, 1], [1, 2], [3, 2], [0, 3]], crossings = new Map();
      for (let e = 0; e < 4; e++) {
        const [a, b] = edges[e]; if ((v[a] > level) === (v[b] > level)) continue;
        const t = (level - v[a]) / (v[b] - v[a]), p = [points[a][0] + t * (points[b][0] - points[a][0]), points[a][1] + t * (points[b][1] - points[a][1])];
        crossings.set(e, { point: p });
      }
      const pairs = { 1: [[0, 3]], 2: [[1, 0]], 3: [[1, 3]], 4: [[2, 1]], 5: [[0, 1], [2, 3]], 6: [[2, 0]], 7: [[2, 3]], 8: [[3, 2]], 9: [[0, 2]], 10: [[3, 0], [1, 2]], 11: [[1, 2]], 12: [[3, 1]], 13: [[0, 1]], 14: [[3, 0]] };
      for (const [a, b] of pairs[code] || []) add(crossings.get(a), crossings.get(b));
    }
    // Directed segment assembly preserves skimage's exact-level vertex ties.
    const paths = new Map(), starts = new Map(), ends = new Map(); let nextID = 0;
    const pointKey = p => p.join(',');
    for (const [from, to] of segments) {
      const fk = pointKey(from), tk = pointKey(to), tail = starts.get(tk), head = ends.get(fk); starts.delete(tk); ends.delete(fk);
      if (tail && head) {
        if (tail === head) head.vertices.push(to);
        else if (tail.id > head.id) { head.vertices.push(...tail.vertices); paths.delete(tail.id); starts.set(pointKey(head.vertices[0]), head); ends.set(pointKey(head.vertices.at(-1)), head); }
        else { tail.vertices.unshift(...head.vertices); starts.delete(pointKey(head.vertices[0])); paths.delete(head.id); starts.set(pointKey(tail.vertices[0]), tail); ends.set(pointKey(tail.vertices.at(-1)), tail); }
      } else if (!tail && !head) {
        const path = { id: nextID++, vertices: [from, to] }; paths.set(path.id, path); starts.set(fk, path); ends.set(tk, path);
      } else if (!head) { tail.vertices.unshift(from); starts.set(fk, tail); }
      else { head.vertices.push(to); ends.set(tk, head); }
    }
    const polygons = [];
    for (const { vertices } of paths.values()) {
      if (vertices.length < 4 || pointKey(vertices[0]) !== pointKey(vertices.at(-1))) continue;
      let area2 = 0;
      for (let i = 1; i < vertices.length; i++) area2 += vertices[i - 1][0] * vertices[i][1] - vertices[i][0] * vertices[i - 1][1];
      if (Math.abs(area2) > 1e-14) polygons.push({ vertices, area: Math.abs(area2) / 2, signedArea: area2 / 2 });
    }
    if (!polygons.length) return null;
    const polygon = polygons.reduce((a, b) => a.area >= b.area ? a : b), v = polygon.signedArea < 0 ? polygon.vertices.slice().reverse() : polygon.vertices;
    // Shift before polygon sums to avoid cancellation for far-from-origin ROIs.
    const ox = v[0][0], oy = v[0][1]; let twice = 0, sx = 0, sy = 0, sxx = 0, syy = 0, sxy = 0, perimeter = 0;
    for (let i = 1; i < v.length; i++) {
      const x = v[i - 1][0] - ox, y = v[i - 1][1] - oy, u = v[i][0] - ox, w = v[i][1] - oy, c = x * w - u * y;
      twice += c; sx += (x + u) * c; sy += (y + w) * c;
      sxx += (x * x + x * u + u * u) * c; syy += (y * y + y * w + w * w) * c;
      sxy += (2 * x * y + x * w + u * y + 2 * u * w) * c; perimeter += Math.hypot(u - x, w - y);
    }
    const area = twice / 2, cx = sx / (6 * area), cy = sy / (6 * area);
    const e = eigen(sxx / (12 * area) - cx * cx, sxy / (24 * area) - cx * cy, syy / (12 * area) - cy * cy);
    const major = 4 * Math.sqrt(e.l1) * pixelSize, minor = 4 * Math.sqrt(e.l2) * pixelSize, aspect = major / minor;
    return { area: area * pixelSize ** 2, perimeter: perimeter * pixelSize, circularity: 4 * Math.PI * area / (perimeter * perimeter), major, minor, aspect,
      angle: e.angle, x: (cx + ox + originX) * pixelSize, y: (cy + oy + originY) * pixelSize,
      orientationReliable: Number.isFinite(aspect) && aspect >= 1.05, closedContourCount: polygons.length,
      vertices: v.map(([x, y]) => [(x + originX) * pixelSize, (y + originY) * pixelSize]) };
  }
  function poisson(mu, r) {
    if (mu > 30) return Math.max(0, Math.round(mu + Math.sqrt(mu) * r.normal()));
    const limit = Math.exp(-mu); let product = 1, k = 0;
    do { k++; product *= r.uniform(); } while (product > limit);
    return k - 1;
  }
  function simulate(params, continuation) {
    const p = { ...defaults, ...params }, n = p.resolution, timingInfo = timing(p);
    p.betweenLineChannels = timingInfo.betweenLineChannels;
    const profile = makeProfile(p), initial = continuation ? continuation.particles.map(q => ({ ...q, z: p.motion3D ? (q.z || 0) : 0 })) : createParticles(p);
    const particles = initial.map(q => ({ ...q })), frameIndex = continuation ? continuation.frameIndex + 1 : 1;
    const random = rng(p.seed + frameIndex * 7919), noiseRandom = rng(p.seed + frameIndex * 104729), [vx, vy] = velocity(p), D = diffusion(p);
    const axialRandom = rng(p.seed + frameIndex * 7919 + 0x9E3779B9);
    const image = new Float32Array(n * n), ideal = new Float32Array(n * n), stationary = new Float32Array(n * n);
    const contourFields = particles.map(() => ({ values: new Map(), x0: n, y0: n, x1: -1, y1: -1 }));
    const moments = particles.map(q => emptyMoments(q.id)), paths = particles.map(() => []), values = new Float64Array(particles.length);
    let currentTime = 0;
    const moveTo = t => { const dt = Math.max(0, t - currentTime), sd = Math.sqrt(2 * D * dt);
      for (const q of particles) {
        q.x += vx * dt + (D ? sd * random.normal() : 0);
        q.y += vy * dt + (D ? sd * random.normal() : 0);
        if (p.motion3D && D) q.z += sd * axialRandom.normal();
      }
      currentTime = t; };
    const record = t => particles.forEach((q, k) => paths[k].push({ t, x: q.x, y: q.y, z: q.z }));
    record(0);
    for (let row = 0; row < n; row++) {
      const yIndex = p.slowDirection === 1 ? row : n - 1 - row, y = (yIndex + 0.5) * timingInfo.pixelSize;
      const dir = p.fastDirection * ((p.bidirectional && row % 2 === 1) ? -1 : 1);
      for (let col = 0; col < n; col++) {
        const xIndex = dir === 1 ? col : n - 1 - col, x = (xIndex + 0.5) * timingInfo.pixelSize, index = yIndex * n + xIndex;
        values.fill(0);
        const samples = p.dwellSamples;
        for (let s = 0; s < samples; s++) {
          moveTo(row * timingInfo.targetLineTime + (col + (s + 0.5) / samples) * timingInfo.dwell);
          for (let k = 0; k < particles.length; k++) {
            const q = particles[k], dx = x - q.x, dy = y - q.y;
            if (Math.abs(dx) < profile.extent && Math.abs(dy) < profile.extent)
              values[k] += sampleProfile(profile, Math.hypot(dx, dy), q.z) / samples;
          }
        }
        let sum = 0, above = 0;
        for (let k = 0; k < particles.length; k++) {
          const value = values[k]; sum += value;
          if (value > 0) { const field = contourFields[k]; field.values.set(index, value);
            field.x0 = Math.min(field.x0, xIndex); field.x1 = Math.max(field.x1, xIndex);
            field.y0 = Math.min(field.y0, yIndex); field.y1 = Math.max(field.y1, yIndex); }
          if (value >= p.threshold) {
            above++;
            addMoment(moments[k], x, y, value, xIndex <= 1 || yIndex <= 1 || xIndex >= n - 2 || yIndex >= n - 2);
          }
          const ref = initial[k]; stationary[index] += sampleProfile(profile, Math.hypot(x - ref.x, y - ref.y), ref.z);
        }
        if (above > 1) values.forEach((w, k) => { if (w >= p.threshold) moments[k].overlap = true; });
        ideal[index] = sum;
        image[index] = p.noise ? Math.max(0, (poisson(sum * p.photons + p.background, noiseRandom) + p.readNoise * noiseRandom.normal()) / p.photons) : sum;
        if (col % Math.max(1, Math.floor(n / 8)) === 0) record(currentTime);
      }
    }
    moveTo(timingInfo.frameTime); record(currentTime);
    const metrics = moments.map((m, k) => {
      const intensity = summarize(m, p, profile), field = contourFields[k]; let contour = null;
      if (field.values.size && m.pixels >= 5) {
        const width = field.x1 - field.x0 + 3, height = field.y1 - field.y0 + 3, scalar = new Float64Array(width * height);
        for (const [index, value] of field.values) scalar[(Math.floor(index / n) - field.y0 + 1) * width + index % n - field.x0 + 1] = value;
        contour = intensityContourMetrics(scalar, width, height, p.threshold, timingInfo.pixelSize, field.x0 - .5, field.y0 - .5);
      }
      const hasContour = Boolean(contour && [contour.circularity, contour.area, contour.perimeter, contour.major, contour.minor, contour.aspect].every(Number.isFinite) && contour.minor > 0);
      return { ...intensity, valid: intensity.valid && hasContour, missing: Boolean(intensity.missing || !hasContour), contourMissing: !hasContour,
        initialZ: initial[k].z, finalZ: particles[k].z,
        contourMajor: contour?.major ?? null, contourMinor: contour?.minor ?? null,
        contourAspect: contour?.aspect ?? null, contourAngle: contour?.angle ?? null,
        contourX: contour?.x ?? null, contourY: contour?.y ?? null,
        contourCircularity: contour?.circularity ?? null, contourArea: contour?.area ?? null, contourPerimeter: contour?.perimeter ?? null,
        contourVertices: contour?.vertices ?? null,
        contourMethod: 'linear_marching_squares_high_connected_largest_outer_polygon',
        contourOrientationReliable: intensity.valid && Boolean(contour?.orientationReliable) };
    });
    const good = metrics.filter(m => m.valid);
    const mean = key => good.length ? good.reduce((s, m) => s + m[key], 0) / good.length : null;
    const circularityMean = mean('contourCircularity'), circularitySD = good.length > 1 ? Math.sqrt(good.reduce((sum, m) => sum + (m.contourCircularity - circularityMean) ** 2, 0) / (good.length - 1)) : null;
    return { p, timing: timingInfo, profile, initial, final: particles, frameIndex, paths, image, ideal, stationary, metrics,
      summary: { count: good.length, majorRatio: mean('majorRatio'), minorRatio: mean('minorRatio'), aspect: mean('aspect'), areaError: mean('areaError'),
        missingCount: metrics.filter(m => m.missing).length, diffusion: D, dimensions: p.motion3D ? 3 : 2,
        contourMajor: mean('contourMajor'), contourMinor: mean('contourMinor'), contourAspect: mean('contourAspect'),
        contourCircularity: circularityMean, circularity: circularityMean, circularitySD,
        contourDefinition: '4πA/P²; largest closed outer linearly interpolated isointensity polygon; high-connected diagonals; noiseless per-ID signal' },
      theory: theoretical(p), continuation: { particles, frameIndex } };
  }
  function positionAt(path, t) {
    let lo = 0, hi = path.length - 1;
    while (hi - lo > 1) { const mid = (lo + hi) >>> 1; if (path[mid].t <= t) lo = mid; else hi = mid; }
    const a = path[lo], b = path[hi], f = Math.max(0, Math.min(1, (t - a.t) / Math.max(1e-12, b.t - a.t)));
    return { x: a.x + (b.x - a.x) * f, y: a.y + (b.y - a.y) * f, z: (a.z || 0) + ((b.z || 0) - (a.z || 0)) * f };
  }
  return { defaults, rng, timing, acquisitionPhase, velocity, waterViscosity, stokesEinstein, diffusion, makeProfile, sampleProfile,
    createParticles, eigen, theoretical, binaryContourEllipse, intensityContourMetrics, simulate, positionAt };
});
