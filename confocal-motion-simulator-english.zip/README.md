# Confocal Motion Imaging Simulator

An offline teaching simulator for particle motion during point-scanned confocal acquisition. Open `confocal-motion-simulator.html` in a modern browser, or open `index.html` while keeping `app.js`, `model.js`, and `style.css` beside it. All calculations and exports run locally.

## What it models

- Uniformly fluorescent solid spheres moving in 2D or 3D, with directed drift, Brownian diffusion, or both.
- A fixed focal plane and a 3D Gaussian point-spread function (PSF). Defocus changes signal brightness and the apparent cross-section.
- Raster acquisition in which each pixel is sampled at its own time. The scan direction, line rate, active fraction, resolution, and number of intervening channel line slots are configurable.
- Particle-level contour measurements, parameter sweeps, and CSV / PNG / JSON exports.

## Acquisition timing

`lineHz` is the base single-channel line-slot rate in Hz. A target-channel line is acquired once per target row. If `x` other-channel slots are inserted between target lines, then:

- Target-line start spacing is `(1 + x) / lineHz`.
- Effective target-row rate is `lineHz / (1 + x)`.
- For an `N × N` image, the modeled frame period is `N(1 + x) / lineHz`.
- Pixel dwell remains `activeFraction / (N × lineHz)`; inserting channels increases time between target rows but does not lengthen target pixel dwell.
- The model treats unused time in each line slot as retrace or turnaround. It does not add separate inter-frame overhead or channel-switching overhead.

For the requested timing scenario—**700 Hz, four averages per line, and one other channel** (two channels total)—use the effective-spacing estimate `8 / 700 s = 0.0114286 s`, or **11.43 ms** between target-line starts (**87.5 target lines/s**). Approximate that spacing in this simulator with `lineHz = 175` and `Between lines = 1`: the modeled interval is `(1 + 1) / 175 = 8 / 700 s`. This matches the effective target-line spacing only. The simulator does not perform four repeated line averages, accumulate their signal, or model averaging-related noise reduction. Its `Between lines` control inserts one other-channel time slot after each target line; it is not a line-average control. Setting `lineHz = 700` and `Between lines = 1` would instead produce a modeled target-line interval of `2 / 700 s = 2.86 ms`, because this model has no four-average option.

## Physics assumptions and limitations

For water mode, the Stokes–Einstein relation is used: `D = kB T / (3 π η d)`, with a temperature-dependent bulk-water viscosity approximation. Brownian increments are independent Gaussian steps with variance `2DΔt` per axis. In 3D the expected diffusion MSD is `6DΔt`; in the xy projection it is `4DΔt`.

Particles are noninteracting, experience no walls or confinement, and are not reflected or wrapped at the field-of-view boundary. The optical model uses a uniformly emitting solid sphere convolved with an idealized 3D Gaussian PSF. It does not model photobleaching, aberrations, resonant sinusoidal scanner motion, detailed galvanometer retrace paths, detector bandwidth, real segmentation errors, or channel crosstalk. Noise settings are illustrative and do not represent a calibrated detector.

This is a generic point-scanning model. Although the interface may mention Leica TCS SP8 as an example of raster acquisition, this release is **not calibrated to Leica hardware** and is not a hardware digital twin. Use instrument logs and measured PSF, pixel size, line timing, and dwell time to set experiment-specific values.

Shape summaries use a linearly interpolated outer contour at the configured threshold on each known particle’s noise-free signal. Area, perimeter, area moments, equivalent-ellipse axes, aspect ratio, and circularity are computed from that contour. Circularity is `C = 4πA/P²`, where `A` is contour area and `P` is contour perimeter; it is dimensionless and sensitive to threshold and pixel resolution. Particles touching an image edge, overlapping, or below threshold are excluded from the primary valid-particle summaries. Reported mean ± sample SD describes a particle distribution; it is not a confidence interval. The simulator measures isolated, known-ID noiseless signals. Experimental contours come from thresholded observed-channel images; the formula and perimeter definition match, but the input signals and segmentation processes differ, so matching definitions do not make simulation and experiment values identical.

## Examples

The `examples/` directory contains a sample configuration and sample particle-measurement table exported by the simulator. These are software examples, not experimental observations or instrument-calibration data.

## Build and verification

Requires Node.js. Run `npm test` to execute the model checks and `npm run build` to rebuild the standalone HTML file. The build embeds the CSS and JavaScript and requires no external resources.

The interpolated contour tracing routine is adapted from scikit-image. See `THIRD_PARTY_NOTICES.txt` for the upstream license and copyright notices; the standalone HTML embeds the same notice.
