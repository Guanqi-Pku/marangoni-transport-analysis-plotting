(function () {
  'use strict';
  const M = window.ConfocalModel, $ = id => document.getElementById(id);
  let p = { ...M.defaults }, result, progress = 1, playing = false, lastTick = 0, timer, dirty = false, sweepRows = [], sweepRawRows = [], sweepBusy = false, sweepCancelRequested = false;
  let imageLayer = document.createElement('canvas');
  const numericFields = ['speed', 'angle', 'diffusion', 'diameter', 'count', 'lineHz', 'fov', 'psfXY', 'psfZ', 'duty', 'photons', 'threshold', 'seed', 'temperatureC', 'initialZStd'];
  const colors = { teal: '#267c68', peach: '#d99b78', muted: '#93a28d', grid: '#e8ede4' };
  const fmt = (n, d = 2) => n === null || n === undefined || !Number.isFinite(n) ? '—' : n.toFixed(d);
  const signed = (n, d = 1) => n === null || n === undefined ? '—' : `${n >= 0 ? '+' : ''}${(n * 100).toFixed(d)}%`;
  function toast(message) { $('toast').textContent = message; $('toast').classList.add('visible'); clearTimeout(toast.timer); toast.timer = setTimeout(() => $('toast').classList.remove('visible'), 3000); }
  function syncControls() {
    numericFields.forEach(key => { $(key).value = p[key]; if ($(key + 'Range')) $(key + 'Range').value = p[key]; });
    ['resolution', 'slowDirection', 'fastDirection', 'dwellSamples', 'betweenLineChannels'].forEach(key => $(key).value = p[key]);
    $('noise').checked = p.noise; $('scanMode').value = p.bidirectional ? 'bi' : 'uni';
    $('motion3D').value = p.motion3D ? '3d' : '2d'; $('diffusionModel').value = p.diffusionModel;
    $('randomXY').checked = p.randomXY;
    document.querySelectorAll('[data-mode]').forEach(b => b.classList.toggle('active', b.dataset.mode === p.mode));
    document.querySelectorAll('.directed').forEach(el => el.style.display = p.mode === 'brownian' ? 'none' : '');
    document.querySelectorAll('.brownian').forEach(el => el.style.display = p.mode === 'directed' ? 'none' : 'block');
    $('compass').querySelector('i').style.transform = `rotate(${p.angle}deg)`;
    updateTiming();
  }
  function updateTiming() {
    const t = M.timing(p);
    $('speedRange').max = Math.max(2, p.speed); $('speedRange').value = p.speed;
    $('fps').textContent = `${fmt(t.fps, 2)} fps`;
    $('frameTime').textContent = `${fmt(t.frameTime, 3)} s`;
    $('dwell').textContent = `${fmt(t.dwell * 1e6, 2)} µs`;
    $('targetLineTime').textContent = `${fmt(t.targetLineTime * 1000, 2)} ms`;
    $('targetRowHz').textContent = `${fmt(1 / t.targetLineTime, 2)} lines/s`;
    const extra = p.betweenLineChannels || 0;
    $('timingSlots').innerHTML = `<span class="timing-slot target" data-slot="0"><b>Target channel</b><small>scan + retrace</small></span>${Array.from({ length: extra }, (_, i) => `<i>→</i><span class="timing-slot other" data-slot="${i + 1}"><b>Other channel ${i + 1}</b><small>particles keep moving</small></span>`).join('')}<i>→</i><span class="timing-slot next"><b>Next target line</b><small>interval ${fmt(t.targetLineTime * 1000, 2)} ms</small></span>`;
    $('timingExplanation').textContent = `Each channel line slot is ${fmt(t.lineTime * 1000, 2)} ms. The target channel is acquired once every ${extra + 1} line slots. Pixel dwell remains ${fmt(t.dwell * 1e6, 2)} µs. ${extra ? 'Time spent on other channels between target lines, including after the final line, is included in the frame period.' : 'Single-channel acquisition; no other-channel slots are inserted.'}`;
    const water = p.diffusionModel === 'water', D = M.diffusion(p), dim = p.motion3D ? 3 : 2;
    $('diffusion').disabled = $('diffusionRange').disabled = water;
    if (water) { $('diffusion').value = fmt(D, 4); $('diffusionRange').value = D; }
    $('temperatureC').disabled = !water;
    $('initialZStd').disabled = !p.motion3D;
    $('effectiveD').textContent = `${fmt(D, 4)} µm²/s`;
    $('viscosity').textContent = `${fmt(M.waterViscosity(p.temperatureC) * 1000, 3)} mPa·s`;
    $('diffusionHint').textContent = water ? `Stokes–Einstein in water: D = kBT/(3πηd), updated with diameter and temperature.${p.mode === 'directed' ? ' D = 0 in directed-only mode.' : ''}` : `Manual D; MSD per axis = 2DΔt. ${p.motion3D ? '3D' : '2D'} total MSD = ${2 * dim}DΔt.`;
    $('rms3D').textContent = `${fmt(Math.sqrt(2 * dim * D * t.frameTime), 3)} µm`;
    $('rmsLabel').textContent = `${p.motion3D ? '3D' : '2D'} diffusion RMS per frame`;
    $('rmsZ').textContent = `${fmt(p.motion3D ? Math.sqrt(2 * D * t.frameTime) : 0, 3)} µm`;
    $('focusMode').textContent = p.motion3D ? 'xy optical slice · z changes brightness and cross-section' : '2D motion · sphere centers remain at z = 0';
  }
  function schedule() {
    dirty = true;
    clearTimeout(timer); playing = false; updatePlay();
    $('computeStatus').textContent = 'Computing…';
    document.querySelectorAll('[data-preset]').forEach(b => b.classList.remove('active'));
    timer = setTimeout(() => compute(), 170);
  }
  function compute(continuation) {
    dirty = false;
    result = M.simulate(p, continuation); progress = 1; playing = false;
    window.confocalExperiment = result;
    imageLayer = makeImageLayer(result.image, p.resolution);
    updateStats(); drawViews(); updatePlay();
    $('computeStatus').textContent = 'Ready';
    $('frameNumber').textContent = String(result.frameIndex).padStart(3, '0');
    if (!sweepBusy) $('sweepStatus').textContent = sweepRows.length ? 'Acquisition settings updated; previous sweep results are retained below. Rerun if needed.' : '8 conditions; set 1–100 repeats per condition. The sweep uses a snapshot of the current settings.';
  }
  function ensureResult() { if (dirty) { clearTimeout(timer); compute(); } }
  numericFields.forEach(key => {
    const input = $(key), range = $(key + 'Range');
    input.addEventListener('input', () => {
      const value = Number(input.value);
      if (input.value === '' || !Number.isFinite(value) || value < Number(input.min) || value > Number(input.max)) { input.classList.add('invalid'); return; }
      input.classList.remove('invalid'); p[key] = ['count', 'seed'].includes(key) ? Math.round(value) : value;
      if (range) range.value = p[key];
      if (key === 'angle') $('compass').querySelector('i').style.transform = `rotate(${value}deg)`;
      updateTiming(); schedule();
    });
    input.addEventListener('change', () => { if (input.classList.contains('invalid')) { input.value = p[key]; input.classList.remove('invalid'); toast('Restored the last valid setting.'); } else input.value = p[key]; });
    if (range) range.addEventListener('input', () => { p[key] = Number(range.value); input.value = p[key]; input.classList.remove('invalid'); updateTiming(); if (key === 'angle') $('compass').querySelector('i').style.transform = `rotate(${p.angle}deg)`; schedule(); });
  });
  ['resolution', 'slowDirection', 'fastDirection', 'dwellSamples', 'betweenLineChannels'].forEach(key => $(key).addEventListener('change', () => { p[key] = Number($(key).value); updateTiming(); schedule(); }));
  $('scanMode').addEventListener('change', () => { p.bidirectional = $('scanMode').value === 'bi'; schedule(); });
  $('noise').addEventListener('change', () => { p.noise = $('noise').checked; schedule(); });
  $('motion3D').addEventListener('change', () => { p.motion3D = $('motion3D').value === '3d'; updateTiming(); schedule(); });
  $('diffusionModel').addEventListener('change', () => { p.diffusionModel = $('diffusionModel').value; syncControls(); schedule(); });
  $('randomXY').addEventListener('change', () => { p.randomXY = $('randomXY').checked; schedule(); });
  document.querySelectorAll('[data-mode]').forEach(b => b.addEventListener('click', () => { p.mode = b.dataset.mode; syncControls(); schedule(); }));
  const presets = {
    default: { mode: 'mixed', speed: .4, angle: 0, diameter: 2.5, motion3D: true, diffusionModel: 'water', randomXY: true },
    directed: { mode: 'directed', speed: .4, angle: 0, diameter: 2.5, motion3D: true, initialZStd: .5 },
    stretch: { mode: 'directed', speed: 12, angle: 90, diameter: 2.5, motion3D: false, initialZStd: 0, randomXY: false },
    compress: { mode: 'directed', speed: 12, angle: 270, diameter: 2.5, motion3D: false, initialZStd: 0, randomXY: false },
    random: { mode: 'brownian', diffusionModel: 'water', motion3D: true, diameter: 2.5 },
    static: { mode: 'directed', speed: 0, angle: 0, initialZStd: 0, motion3D: false }
  };
  document.querySelectorAll('[data-preset]').forEach(b => b.addEventListener('click', () => {
    p = { ...M.defaults, ...presets[b.dataset.preset], betweenLineChannels: p.betweenLineChannels || 0 }; syncControls(); clearTimeout(timer); compute();
    document.querySelectorAll('[data-preset]').forEach(q => q.classList.toggle('active', q === b));
  }));
  $('reset').addEventListener('click', () => { p = { ...M.defaults }; syncControls(); clearTimeout(timer); compute(); document.querySelectorAll('[data-preset]').forEach(b => b.classList.toggle('active', b.dataset.preset === 'default')); toast('Settings and random seed reset.'); });
  function showPage(page) {
    if (page !== 'simulation') playing = false;
    document.querySelectorAll('[data-page]').forEach(b => b.classList.toggle('active', b.dataset.page === page));
    document.querySelectorAll('.page').forEach(el => el.classList.toggle('active', el.id === page + 'Page'));
    updatePlay(); window.scrollTo({ top: 0, behavior: 'smooth' });
  }
  document.querySelectorAll('[data-page]').forEach(b => b.addEventListener('click', () => showPage(b.dataset.page)));
  document.querySelectorAll('[data-goto]').forEach(b => b.addEventListener('click', () => showPage(b.dataset.goto)));

  function updateStats() {
    const s = result.summary, t = result.theory, tt = result.timing, d = particleDistribution(result.metrics);
    $('majorMetric').textContent = fmt(d.major.mean, 3);
    $('minorMetric').textContent = fmt(d.minor.mean, 3);
    $('aspectMetric').textContent = fmt(d.aspect.mean, 3);
    $('areaMetric').textContent = `${d.count} / ${p.count}`;
    $('majorDetail').textContent = `Sample SD ${fmt(d.major.sd, 3)} µm`;
    $('minorDetail').textContent = `Sample SD ${fmt(d.minor.sd, 3)} µm`;
    $('aspectDetail').textContent = `Sample SD ${fmt(d.aspect.sd, 3)} · A circle has an aspect ratio of 1`;
    $('validDetail').textContent = `Valid orientations: ${d.angle.n}; near-circular particles excluded: ${d.nearCircular}`;
    const modeName = { directed: 'constant-velocity drift', brownian: 'Brownian diffusion', mixed: 'drift + diffusion' }[p.mode];
    $('motionDescription').textContent = `${p.motion3D ? '3D' : '2D'} ${modeName} · ${p.diameter} µm · D ${fmt(M.diffusion(p), 3)}`;
    $('pixelInfo').textContent = `${p.resolution} × ${p.resolution} px · ${fmt(tt.pixelSize, 3)} µm/px`;
    const theoryUsable = t.applicable && !t.singular;
    $('theoryMajor').textContent = theoryUsable ? `${fmt(t.majorRatio, 3)}×` : '—';
    $('theoryMinor').textContent = theoryUsable ? `${fmt(t.minorRatio, 3)}×` : '—';
    $('theoryAngle').textContent = theoryUsable && Math.abs(t.aspect - 1) > 1e-4 ? `${fmt(t.angle, 1)}°` : '—';
    $('theoryNote').textContent = theoryUsable ? `Unidirectional scan, continuous-sampling limit for a static in-focus circle. Slow-axis speed: ${fmt(tt.slowSpeed)} µm/s; velocity ratio along the slow axis β = ${fmt(t.beta, 3)}. Angle is clockwise from image right.` : p.bidirectional ? 'Bidirectional scanning reverses the fast-axis time gradient on alternate lines, so no single frame-wide affine prediction applies; the pixel simulation is shown above.' : p.mode !== 'directed' ? 'Brownian paths are not a constant-velocity affine transform, so there is no single deterministic ellipse-axis ratio. In 3D, z diffusion also changes slice brightness and contour. Use the parameter sweep to evaluate multiple seeds.' : p.motion3D ? 'In 3D, particles may start out of focus, so axis ratios also reflect optical-section changes and should not be compared directly with 2D in-focus affine theory. Switch to 2D to view the theoretical prediction.' : 'Motion and scanning approach a time-mapping singularity; a finite ellipse cannot be predicted. Check for edge contact or lost particles.';
    const edgeCount = result.metrics.filter(m => m.edge).length, overlapCount = result.metrics.filter(m => m.overlap).length;
    let title, body;
    if (p.mode === 'brownian' || p.mode === 'mixed') {
      const D = M.diffusion(p), rms = Math.sqrt((p.motion3D ? 6 : 4) * D * tt.frameTime), rmsZ = Math.sqrt(2 * D * tt.frameTime);
      title = `${p.motion3D ? '3D' : '2D'} diffusion RMS per frame: ${fmt(rms)} µm; x drift ${fmt((p.mode === 'brownian' ? 0 : p.speed * Math.cos(p.angle * Math.PI / 180)) * tt.frameTime)} µm`;
      body = `${p.motion3D ? `Total displacement scale √(6DT); xy projection √(4DT) = ${fmt(Math.sqrt(4 * D * tt.frameTime))} µm; z-axis √(2DT) = ${fmt(rmsZ)} µm. Defocus along z dims the signal and shrinks the cross-section; particles may move out of focus. `: 'This is the RMS displacement of 2D diffusion, √(4DT). '}RMS displacement is not the same as image blur diameter. ${p.diffusionModel === 'water' ? `${p.temperatureC}°C water: D = ${fmt(D, 4)} µm²/s. Smaller particles diffuse faster. ` : ''}Point-by-point scanning records this random path in the contour.`;
    } else if (!p.speed) { title = 'Stationary particles retain their circular shape and are the baseline for this experiment.'; body = `The theoretical axis magnification is 1. Optical blur, sphere brightness distribution, and thresholds change the equivalent measured diameter, so the stationary signal of the same PSF is used for normalization.`; }
    else {
      title = t.beta > 0 ? 'Motion along the slow scan axis tends to stretch the acquired image.' : t.beta < -0.001 ? 'Motion against the slow scan axis tends to compress the acquired image.' : 'Lateral drift can tilt the image because each row is acquired at a different position.';
      body = `Frame time: ${fmt(tt.frameTime, 3)} s. Drift distance during the frame: ${fmt(p.speed * tt.frameTime)} µm (${fmt(p.speed * tt.frameTime / p.diameter, 2)} particle diameters). A higher line rate or fewer scan lines shortens the frame time.`;
    }
    if (p.betweenLineChannels) body += `Insert ${p.betweenLineChannels} other-channel line slots, target interval ${fmt(tt.targetLineTime * 1000, 2)} ms; pixel dwell is still ${fmt(tt.dwell * 1e6, 2)} µs.`;
    if (edgeCount || overlapCount) body += ` ${edgeCount} particle(s) touch the image edge and ${overlapCount} overlap; these are excluded from the summary.`;
    if (p.diameter / tt.pixelSize < 6) body += ' The particle diameter spans fewer than 6 pixels, so size quantization is coarse.';
    if (Math.abs(t.determinant) < 0.15) body += ' Motion is close to the scan catch-up condition, so the full contour may not be captured.';
    $('insightTitle').textContent = title; $('insightBody').textContent = body;
    $('particleTable').innerHTML = result.metrics.map((m, k) => `<tr><td><span class="dot teal"></span>P${String(m.id).padStart(2, '0')}</td><td>${fmt(m.contourMajor)}</td><td>${fmt(m.contourMinor)}</td><td>${fmt(m.contourAspect)}</td><td>${fmt(m.contourCircularity, 4)}</td><td>${fmt(m.contourArea, 3)}</td><td>${fmt(m.contourPerimeter, 3)}</td><td>${m.contourOrientationReliable ? fmt(m.contourAngle, 1) : '—'}</td><td>${m.missing ? 'Insufficient signal' : !m.valid ? 'Excluded from orientation' : m.contourAspect < 1.05 ? 'Near-circular / excluded from orientation' : 'Reliable'}</td><td>${fmt(result.initial[k].z || 0, 3)}</td><td>${fmt(M.positionAt(result.paths[k], tt.frameTime).z || 0, 3)}</td><td><span class="status ${m.valid ? '' : 'warn'}">${metricStatus(m)}</span></td></tr>`).join('');
    drawParticleChart(); drawDistributions();
  }
  function metricStatus(m) { return m.missing ? 'Insufficient signal / exit' : [m.edge ? 'At edge' : '', m.overlap ? 'overlapping' : ''].filter(Boolean).join(' · ') || 'Valid'; }
  function makeImageLayer(data, n) {
    const canvas = document.createElement('canvas'); canvas.width = canvas.height = n;
    const ctx = canvas.getContext('2d'), img = ctx.createImageData(n, n), palette = $('palette').value;
    const rgb = palette === 'green' ? [95, 240, 162] : palette === 'cyan' ? [100, 222, 235] : [229, 238, 232];
    for (let i = 0; i < data.length; i++) {
      const f = Math.pow(Math.min(1, Math.max(0, data[i]) / 1.3), 0.85), q = i * 4;
      img.data[q] = 8 + f * rgb[0]; img.data[q + 1] = 23 + f * rgb[1]; img.data[q + 2] = 18 + f * rgb[2]; img.data[q + 3] = 255;
    }
    ctx.putImageData(img, 0, 0); return canvas;
  }
  function prepareCanvas(canvas) {
    const ctx = canvas.getContext('2d'), size = canvas.width, pad = size * 0.065, side = size - pad * 1.55;
    ctx.fillStyle = '#091b17'; ctx.fillRect(0, 0, size, size);
    ctx.strokeStyle = '#153128'; ctx.lineWidth = 0.7; ctx.font = `${size * .015}px Consolas, monospace`; ctx.fillStyle = '#4c7565';
    for (let i = 0; i <= 4; i++) {
      const q = pad + side * i / 4;
      ctx.beginPath(); ctx.moveTo(q, pad); ctx.lineTo(q, pad + side); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(pad, q); ctx.lineTo(pad + side, q); ctx.stroke();
      ctx.fillText(fmt(p.fov * i / 4, p.fov % 4 ? 1 : 0), q - 4, pad - 12);
      ctx.fillText(fmt(p.fov * i / 4, p.fov % 4 ? 1 : 0), 7, q + 3);
    }
    ctx.fillText('µm', pad + side - 14, pad - 26);
    return { ctx, size, pad, side, scale: side / p.fov };
  }
  function scaleBar(g) {
    const { ctx, pad, side, scale, size } = g;
    const ideal = p.fov / 5, power = 10 ** Math.floor(Math.log10(ideal)), bar = (ideal / power >= 5 ? 5 : ideal / power >= 2 ? 2 : 1) * power;
    const x = pad + side - bar * scale - 13, y = pad + side - 18;
    ctx.fillStyle = '#afc9b9'; ctx.fillRect(x, y, bar * scale, 2);
    ctx.font = `${size * .016}px Consolas, monospace`; ctx.textAlign = 'center'; ctx.fillText(`${bar} µm`, x + bar * scale / 2, y - 9); ctx.textAlign = 'left';
  }
  function renderTruth(canvas, fraction) {
    const g = prepareCanvas(canvas), { ctx, pad, side, scale, size } = g, time = fraction * result.timing.frameTime;
    const n = Math.min(256, p.resolution), pixel = p.fov / n, signal = new Float32Array(n * n);
    const positions = result.paths.map(path => M.positionAt(path, time));
    // Render the actual instantaneous optical section, on the same absolute scale as the raster image.
    for (const q of positions) {
      const e = result.profile.extent, x0 = Math.max(0, Math.floor((q.x - e) / pixel)), x1 = Math.min(n - 1, Math.ceil((q.x + e) / pixel));
      const y0 = Math.max(0, Math.floor((q.y - e) / pixel)), y1 = Math.min(n - 1, Math.ceil((q.y + e) / pixel));
      for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) signal[y * n + x] += M.sampleProfile(result.profile, Math.hypot((x + .5) * pixel - q.x, (y + .5) * pixel - q.y), q.z || 0);
    }
    ctx.imageSmoothingEnabled = true; ctx.drawImage(makeImageLayer(signal, n), pad, pad, side, side);
    ctx.save(); ctx.beginPath(); ctx.rect(pad, pad, side, side); ctx.clip();
    for (let k = 0; k < result.paths.length; k++) {
      const path = result.paths[k], q = positions[k], cx = pad + q.x * scale, cy = pad + q.y * scale, radius = p.diameter * scale / 2;
      if ($('showTrails').checked) {
        ctx.strokeStyle = '#5b9b7955'; ctx.lineWidth = 1; ctx.setLineDash([3, 4]); ctx.beginPath();
        ctx.arc(pad + path[0].x * scale, pad + path[0].y * scale, radius, 0, 2 * Math.PI); ctx.stroke(); ctx.setLineDash([]);
        ctx.strokeStyle = '#97b49b85'; ctx.beginPath(); ctx.moveTo(pad + path[0].x * scale, pad + path[0].y * scale);
        let last = path[0];
        for (let i = 1; i < path.length && path[i].t <= time; i++) { last = path[i]; ctx.lineTo(pad + last.x * scale, pad + last.y * scale); }
        ctx.lineTo(cx, cy); ctx.stroke();
        if (p.mode !== 'directed') { ctx.fillStyle = '#94bca0'; ctx.fillRect(cx - 1, cy - 1, 2, 2); }
      }
      ctx.strokeStyle = '#87dcb050'; ctx.lineWidth = .8; ctx.setLineDash([2, 3]);
      ctx.beginPath(); ctx.arc(cx, cy, radius, 0, 2 * Math.PI); ctx.stroke(); ctx.setLineDash([]);
      const z = q.z || 0, peak = M.sampleProfile(result.profile, 0, z);
      ctx.font = `${size * .014}px Consolas, monospace`; ctx.fillStyle = peak >= p.threshold ? '#b5ddc1' : '#c99b7d';
      ctx.fillText(`P${String(k + 1).padStart(2, '0')}${p.motion3D ? ` z${z >= 0 ? '+' : ''}${fmt(z, 2)}` : ''}`, cx - radius + 2, cy - radius - 6);
    }
    ctx.restore(); scaleBar(g); return g;
  }
  function renderScan(canvas, fraction) {
    const g = prepareCanvas(canvas), { ctx, pad, side, scale, size } = g, n = p.resolution;
    ctx.imageSmoothingEnabled = true;
    const phase = M.acquisitionPhase(p, fraction * result.timing.frameTime);
    const rows = Math.min(n, Math.floor(phase.acquiredPixels / n)), width = phase.acquiredPixels - rows * n;
    if (rows > 0) {
      const y = p.slowDirection === 1 ? 0 : n - rows;
      ctx.drawImage(imageLayer, 0, y, n, rows, pad, pad + y * side / n, side, rows * side / n);
    }
    const dir = phase.fastDirection, yIndex = phase.rowIndex;
    if (width > 0) {
      const x = dir === 1 ? 0 : n - width;
      ctx.drawImage(imageLayer, x, yIndex, width, 1, pad + x * side / n, pad + yIndex * side / n, width * side / n, side / n);
    }
    if (!phase.complete) {
      const lineY = pad + (yIndex + .5) * side / n, target = phase.phase === 'target-scan';
      ctx.strokeStyle = target ? '#e6a677b5' : '#839d9080'; ctx.lineWidth = 1; ctx.setLineDash(target ? [] : [3, 5]);
      ctx.beginPath(); ctx.moveTo(pad, lineY); ctx.lineTo(pad + side, lineY); ctx.stroke(); ctx.setLineDash([]);
      if (target) {
        const frac = Math.min(1, phase.slotTime / (result.timing.lineTime * p.duty)), x = pad + (dir === 1 ? frac : 1 - frac) * side;
        ctx.fillStyle = '#ffcf97'; ctx.shadowColor = '#f8a86a'; ctx.shadowBlur = 9; ctx.beginPath(); ctx.arc(x, lineY, 2.5, 0, Math.PI * 2); ctx.fill(); ctx.shadowBlur = 0;
      }
    }
    if ($('showEllipses').checked) {
      ctx.save(); ctx.beginPath();
      const y = p.slowDirection === 1 ? pad : pad + side * (1 - rows / n);
      ctx.rect(pad, y, side, side * rows / n);
      if (width > 0) { const x = dir === 1 ? 0 : n - width; ctx.rect(pad + x * side / n, pad + yIndex * side / n, width * side / n, side / n); }
      ctx.clip();
      for (const m of result.metrics) {
        if (m.missing) continue;
        const cx = pad + m.contourX * scale, cy = pad + m.contourY * scale;
        ctx.strokeStyle = m.valid ? '#bad9c994' : '#e6ba8488'; ctx.lineWidth = 1; ctx.setLineDash([5, 4]); ctx.beginPath();
        ctx.ellipse(cx, cy, m.contourMajor * scale / 2, m.contourMinor * scale / 2, m.contourAngle * Math.PI / 180, 0, 2 * Math.PI); ctx.stroke(); ctx.setLineDash([]);
        ctx.font = `${size * .016}px Consolas, monospace`; ctx.fillStyle = m.valid ? '#b7d4bf' : '#c5ac87';
        ctx.fillText(`P${String(m.id).padStart(2, '0')}`, cx + 4, cy - m.contourMajor * scale / 2 - 5);
      }
      ctx.restore();
    }
    scaleBar(g); return g;
  }
  function drawViews() {
    if (!result) return;
    renderTruth($('truthCanvas'), progress); renderScan($('scanCanvas'), progress);
    const t = progress * result.timing.frameTime;
    $('truthTime').textContent = `t = ${fmt(t, 3)} s`;
    const positions = result.paths.map(path => M.positionAt(path, t)), visible = positions.filter(q => M.sampleProfile(result.profile, 0, q.z || 0) >= p.threshold).length;
    $('focusReadout').textContent = p.motion3D ? `Axial signal visible ${visible}/${p.count} · mean |z| ${fmt(positions.reduce((sum, q) => sum + Math.abs(q.z || 0), 0) / positions.length, 2)} µm` : 'All particle centers have z = 0 µm';
    const phase = M.acquisitionPhase(p, t), names = { 'target-scan': 'Target-channel acquisition', 'target-turnaround': 'Target-channel retrace / turnaround', 'other-scan': `Other-channel ${phase.slotIndex} acquisition`, 'other-turnaround': `Other-channel ${phase.slotIndex} retrace / turnaround`, complete: 'Frame cycle complete' };
    $('scanCaption').textContent = `Frame ${result.frameIndex} · ${fmt(100 * phase.acquiredPixels / (p.resolution ** 2), 1)}% acquired`;
    $('scanPhase').textContent = `${names[phase.phase]}${phase.complete ? '' : ` · Target line ${phase.targetRow + 1}/${p.resolution} `}`;
    $('scanPhase').classList.toggle('other-phase', phase.slot === 'other');
    $('scanPhaseDetail').textContent = phase.slot === 'other' ? 'The target image is paused while particle drift and diffusion continue.' : phase.phase === 'target-turnaround' ? 'The target line is complete. The current retrace or turnaround records no target-channel pixels.' : phase.complete ? 'All target lines and the frame cycle are complete. You can acquire the next frame.' : 'The orange marker indicates a target-channel pixel being acquired.';
    document.querySelectorAll('#timingSlots [data-slot]').forEach(el => el.classList.toggle('active', !phase.complete && Number(el.dataset.slot) === phase.slotIndex));
    $('timeReadout').textContent = `${fmt(t, 3)} / ${fmt(result.timing.frameTime, 3)} s`;
    $('progress').value = Math.round(progress * 1000);
  }
  function updatePlay() { $('play').textContent = playing ? 'Ⅱ' : '▶'; $('play').setAttribute('aria-label', playing ? 'Pause scan animation' : 'Play scan demo'); }
  $('play').addEventListener('click', () => { ensureResult(); if (progress >= 1) progress = 0; playing = !playing; lastTick = performance.now(); updatePlay(); });
  $('replay').addEventListener('click', () => { ensureResult(); progress = 0; playing = true; lastTick = performance.now(); updatePlay(); });
  $('progress').addEventListener('input', () => { const nextProgress = Number($('progress').value) / 1000; ensureResult(); playing = false; progress = nextProgress; updatePlay(); drawViews(); });
  $('nextFrame').addEventListener('click', () => { const continuation = dirty ? undefined : result.continuation; clearTimeout(timer); compute(continuation); toast(result.frameIndex === 1 ? 'Settings changed; restarting at frame 1.' : `Frame ${result.frameIndex}: particles continue from their positions at the end of the previous frame.`); });
  ['showTrails', 'showEllipses'].forEach(id => $(id).addEventListener('change', () => { ensureResult(); drawViews(); }));
  $('palette').addEventListener('change', () => { ensureResult(); imageLayer = makeImageLayer(result.image, p.resolution); drawViews(); });
  function tick(now) {
    if (playing) { progress = Math.min(1, progress + (now - lastTick) / Number($('playDuration').value)); lastTick = now; drawViews(); if (progress >= 1) { playing = false; updatePlay(); } }
    requestAnimationFrame(tick);
  }
  function drawParticleChart() {
    const ms = result.metrics, W = 600, H = 220, left = 45, top = 15, bottom = 185, right = 585;
    const max = Math.max(1.5, ...ms.filter(m => !m.missing).map(m => Math.max(m.majorRatio, m.minorRatio))) * 1.1;
    const Y = v => bottom - v / max * (bottom - top), step = (right - left) / ms.length;
    let svg = '';
    for (let i = 0; i <= 3; i++) { const v = max * i / 3; svg += `<path d="M${left},${Y(v)}H${right}" stroke="${colors.grid}"/><text x="${left - 10}" y="${Y(v) + 3}" text-anchor="end" fill="${colors.muted}">${fmt(v, 1)}×</text>`; }
    svg += `<path d="M${left},${Y(1)}H${right}" stroke="#9aaf96" stroke-dasharray="4 4"/>`;
    ms.forEach((m, i) => {
      const x = left + step * (i + .5), bw = Math.min(14, step * .27), opacity = m.valid ? 1 : .3;
      if (!m.missing) {
        svg += `<g opacity="${opacity}"><title>P${m.id}: major axis ${fmt(m.majorRatio, 3)}×, minor axis ${fmt(m.minorRatio, 3)}×, ${metricStatus(m)}</title><rect x="${x - bw - 1}" y="${Y(m.majorRatio)}" width="${bw}" height="${bottom - Y(m.majorRatio)}" rx="2" fill="${colors.teal}"/><rect x="${x + 1}" y="${Y(m.minorRatio)}" width="${bw}" height="${bottom - Y(m.minorRatio)}" rx="2" fill="${colors.peach}"/></g>`;
      }
      svg += `<text x="${x}" y="${bottom + 18}" text-anchor="middle" font-size="${ms.length > 16 ? 7 : 9}" fill="${colors.muted}">${m.id}</text>`;
    });
    svg += `<text x="${right}" y="217" text-anchor="end" fill="${colors.muted}" font-size="9">Particle ID</text>`; $('particleChart').innerHTML = svg;
  }

  function sampleStats(values) {
    const v = values.filter(Number.isFinite), n = v.length;
    if (!n) return { n: 0, mean: null, sd: null };
    const mean = v.reduce((sum, x) => sum + x, 0) / n;
    return { n, mean, sd: n > 1 ? Math.sqrt(v.reduce((sum, x) => sum + (x - mean) ** 2, 0) / (n - 1)) : null };
  }
  function axialStats(angles) {
    const v = angles.filter(Number.isFinite), n = v.length;
    if (!n) return { n: 0, mean: null, sd: null, resultant: null, cos2: null, sin2: null };
    const C = v.reduce((sum, x) => sum + Math.cos(2 * x * Math.PI / 180), 0) / n;
    const S = v.reduce((sum, x) => sum + Math.sin(2 * x * Math.PI / 180), 0) / n;
    const R = Math.min(1, Math.hypot(C, S));
    return { n, mean: R > 1e-6 ? Math.atan2(S, C) * 90 / Math.PI : null,
      sd: n > 1 && R > 1e-6 ? Math.sqrt(Math.max(0, -2 * Math.log(R))) * 90 / Math.PI : null, resultant: R, cos2: C, sin2: S };
  }
  function particleDistribution(metrics) {
    const valid = metrics.filter(m => m.valid && Number.isFinite(m.contourAspect));
    const angles = valid.filter(m => m.contourOrientationReliable && m.contourAspect >= 1.05).map(m => m.contourAngle);
    return { count: valid.length, major: sampleStats(valid.map(m => m.contourMajor)), minor: sampleStats(valid.map(m => m.contourMinor)),
      aspect: sampleStats(valid.map(m => m.contourAspect)), circularity: sampleStats(valid.filter(m => Number.isFinite(m.contourCircularity)).map(m => m.contourCircularity)),
      circularities: valid.filter(m => Number.isFinite(m.contourCircularity)).map(m => m.contourCircularity), angle: axialStats(angles), angles,
      nearCircular: valid.filter(m => m.contourAspect < 1.05).length };
  }
  const meanSD = (s, d = 3) => `${fmt(s.mean, d)} ± ${fmt(s.sd, d)}`;
  function histogram(svgId, series, angle = false) {
    const W = 500, H = 260, L = 44, R = 480, T = 88, B = 215, bins = angle ? 12 : 10;
    const all = series.flatMap(s => s.values).filter(Number.isFinite);
    if (!all.length) { $(svgId).innerHTML = '<text x="250" y="130" text-anchor="middle" fill="#9ba990">No valid data</text>'; return; }
    let lo = angle ? -90 : Math.min(...all), hi = angle ? 90 : Math.max(...all);
    if (!angle) { const stats = series.map(s => sampleStats(s.values)); lo = Math.min(lo, ...stats.filter(s => Number.isFinite(s.mean)).map(s => s.mean - (s.sd ?? 0))); hi = Math.max(hi, ...stats.filter(s => Number.isFinite(s.mean)).map(s => s.mean + (s.sd ?? 0))); const pad = Math.max((hi - lo) * .1, Math.abs(hi) * .025, .02); lo = Math.max(0, lo - pad); hi += pad; }
    const X = v => L + (v - lo) / (hi - lo) * (R - L), counts = series.map(s => {
      const values = Array(bins).fill(0); s.values.filter(Number.isFinite).forEach(v => { const wrapped = angle ? ((v + 90) % 180 + 180) % 180 - 90 : v; values[Math.max(0, Math.min(bins - 1, Math.floor((wrapped - lo) / (hi - lo) * bins)))]++; }); return values;
    });
    const max = Math.max(1, ...counts.flat()), Y = v => B - v / max * (B - T); let svg = '';
    for (let n = 0; n <= max; n += Math.max(1, Math.ceil(max / 4))) svg += `<path d="M${L},${Y(n)}H${R}" stroke="${colors.grid}"/><text x="${L - 8}" y="${Y(n) + 4}" fill="${colors.muted}" text-anchor="end">${n}</text>`;
    series.forEach((s, k) => {
      const step = (R - L) / bins, bw = step / series.length;
      counts[k].forEach((n, j) => svg += `<rect x="${L + j * step + k * bw + 1}" y="${Y(n)}" width="${Math.max(1, bw - 2)}" height="${B - Y(n)}" fill="${s.color}" opacity=".65"><title>${s.label}: ${n} particles</title></rect>`);
      const stat = angle ? axialStats(s.values) : sampleStats(s.values), y = 25 + k * 26;
      svg += `<text x="${L}" y="${y - 8}" fill="${s.color}">${s.label} ${angle ? 'Axial mean ' + fmt(stat.mean, 1) + '°' : meanSD(stat)}${angle ? ' · R₂=' + fmt(stat.resultant, 3) : ''}</text>`;
      if (Number.isFinite(stat.mean)) {
        if (!angle && Number.isFinite(stat.sd)) svg += `<path d="M${X(Math.max(lo, stat.mean - stat.sd))},${y + 2}H${X(Math.min(hi, stat.mean + stat.sd))} M${X(Math.max(lo, stat.mean - stat.sd))},${y - 3}V${y + 7} M${X(Math.min(hi, stat.mean + stat.sd))},${y - 3}V${y + 7}" stroke="${s.color}" stroke-width="2"/>`;
        svg += `<circle cx="${X(stat.mean)}" cy="${y + 2}" r="4" fill="${s.color}"/>`;
        if (angle) svg += `<path d="M${X(stat.mean)},${T}V${B}" stroke="${s.color}" stroke-dasharray="4 3"/>`;
      }
    });
    for (let i = 0; i <= 4; i++) { const v = lo + (hi - lo) * i / 4; svg += `<text x="${X(v)}" y="${B + 20}" text-anchor="middle" fill="${colors.muted}">${fmt(v, angle ? 0 : 2)}${angle ? '°' : ''}</text>`; }
    svg += `<text x="${R}" y="${H - 4}" text-anchor="end" fill="${colors.muted}">${angle ? '180° periodic: −90° and +90° are equivalent' : 'Point = mean; horizontal error bars = sample SD; vertical axis = particle count'}</text>`;
    $(svgId).innerHTML = svg;
  }
  function drawDistributions() {
    const valid = result.metrics.filter(m => m.valid), d = particleDistribution(result.metrics);
    $('distributionCount').textContent = `${d.count}/${p.count} valid particles; ${d.angle.n} reliable orientations; ${d.nearCircular} near-circular particles excluded.`;
    $('contourMajorSummary').textContent = meanSD(d.major); $('contourMinorSummary').textContent = meanSD(d.minor);
    $('contourAspectSummary').textContent = meanSD(d.aspect); $('contourCircularitySummary').textContent = meanSD(d.circularity);
    $('directionSummary').textContent = `${fmt(d.angle.mean, 1)}° · R₂ ${fmt(d.angle.resultant, 3)} · axial circular SD ${fmt(d.angle.sd, 1)}°`;
    histogram('lengthDistribution', [{label:'Contour major axis/µm',values:valid.map(m => m.contourMajor),color:colors.teal},{label:'Contour minor axis/µm',values:valid.map(m => m.contourMinor),color:colors.peach}]);
    histogram('aspectDistribution', [{label:'Contour aspect ratio',values:valid.map(m => m.contourAspect),color:colors.teal}]);
    histogram('circularityDistribution', [{label:'Contour circularity C',values:d.circularities,color:colors.teal}]);
    histogram('directionDistribution', [{label:'Reliable contour orientation',values:d.angles,color:colors.teal}], true);
  }

  const sweepDefinitions = { lineHz: { label: 'Line rate / Hz', min: 100, max: 1200, lo: 10, hi: 12000 }, speed: { label: 'Drift speed / µm/s', min: 0, max: 1.2, lo: 0, hi: 300 }, diameter: { label: 'Sphere diameter / µm', min: .5, max: 5, lo: .2, hi: 15 }, diffusion: { label: 'Manual diffusion coefficient / µm²/s', min: 0, max: 1, lo: 0, hi: 50 } };
  $('sweepVariable').addEventListener('change', () => { const d = sweepDefinitions[$('sweepVariable').value]; $('sweepMin').value = d.min; $('sweepMax').value = d.max; });
  const pause = () => new Promise(resolve => setTimeout(resolve, 0));
  $('cancelSweep').addEventListener('click', () => {
    if (!sweepBusy) return; sweepCancelRequested = true; $('cancelSweep').disabled = true;
    $('sweepStatus').textContent = 'Stopping after the current simulation; completed results will be retained.';
  });
  function updateSweepView() {
    const meta = sweepRows.meta; if (!meta) return;
    $('sweepTitle').textContent = `Contour axes vs. ${meta.label.split(' /')[0]}`; $('sweepColumn').textContent = meta.label;
    $('sweepMetadata').textContent = `${meta.p.motion3D ? '3D' : '2D'} ${meta.p.mode}; ${meta.p.resolution}×${meta.p.resolution}; ${meta.repeats} planned repeats per condition. Repeat r uses seed ${meta.p.seed} + (r−1)×101; the same repeat index uses the same initial positions and seed across conditions. Between-line channels: ${meta.p.betweenLineChannels || 0}. ${meta.parameter === 'diffusion' ? 'This sweep uses manual D.' : meta.p.diffusionModel === 'water' ? `water temperature: ${meta.p.temperatureC}°C; D updates with particle diameter.` : 'Manual D.'}`;
    $('sweepTable').innerHTML = sweepRows.length ? sweepRows.map(r => `<tr><td>${r.x}</td><td>${fmt(r.effectiveD, 4)}</td><td>${meanSD(r.major)}</td><td>${meanSD(r.minor)}</td><td>${meanSD(r.aspect)}</td><td>${meanSD(r.circularity, 4)}</td><td>${fmt(r.angle.mean, 1)}° · R₂ ${fmt(r.angle.resultant, 3)}<br><small>Axial circular SD ${fmt(r.angle.sd, 1)}° · N=${r.angle.n}</small></td><td>${r.major.n} / ${r.attempted} / ${meta.repeats}</td><td>${r.valid} / ${r.total}</td></tr>`).join('') : '<tr><td colspan="9">No completed repeats yet.</td></tr>';
    drawSweep();
  }
  $('runSweep').addEventListener('click', async () => {
    if (sweepBusy) return;
    const key = $('sweepVariable').value, def = sweepDefinitions[key], lo = Number($('sweepMin').value), hi = Number($('sweepMax').value), repeats = Number($('sweepRepeats').value);
    if (!Number.isFinite(lo) || !Number.isFinite(hi) || lo < def.lo || hi > def.hi || lo >= hi) { toast(`Enter an increasing range from ${def.lo} to ${def.hi}.`); return; }
    if (!Number.isInteger(repeats) || repeats < 1 || repeats > 100) { toast('Repeats per condition must be an integer from 1 to 100.'); return; }
    if (key === 'lineHz' && hi - lo < 7) { toast('The range for an 8-level line-rate sweep must span at least 7 Hz.'); return; }
    if ((key === 'speed' && p.mode === 'brownian') || (key === 'diffusion' && p.mode === 'directed')) { toast(key === 'speed' ? 'Switch to directed or mixed mode before sweeping drift speed.' : 'Switch to Brownian or mixed mode before sweeping diffusion.'); return; }
    sweepBusy = true; sweepCancelRequested = false; $('runSweep').disabled = true; $('cancelSweep').disabled = false; $('exportSweep').disabled = true; $('exportSweepRaw').disabled = true;
    const snapshot = { ...p, ...(key === 'diffusion' ? { diffusionModel: 'manual' } : {}) };
    const initialByRepeat = Array.from({ length: repeats }, (_, j) => M.createParticles({ ...snapshot, seed: snapshot.seed + j * 101 }));
    sweepRows = []; sweepRawRows = []; sweepRows.meta = { parameter: key, label: def.label, p: snapshot, repeats, seedStep: 101, status: 'running' };
    $('sweepProgress').max = 8 * repeats; $('sweepProgress').value = 0; updateSweepView();
    let failure = null;
    try {
      for (let i = 0; i < 8 && !sweepCancelRequested; i++) {
        const raw = lo + (hi - lo) * i / 7, x = key === 'lineHz' ? Math.round(raw) : Number(raw.toPrecision(8)), samples = [];
        for (let j = 0; j < repeats && !sweepCancelRequested; j++) {
          $('sweepStatus').textContent = `Completed ${sweepRawRows.length}/${8 * repeats} (${fmt(100 * sweepRawRows.length / (8 * repeats), 1)}%); condition ${i + 1}/8: ${def.label} = ${x}; repeat ${j + 1}/${repeats}…`;
          await pause(); if (sweepCancelRequested) break;
          const q = { ...snapshot, [key]: x, seed: snapshot.seed + j * 101 };
          const r = M.simulate(q, { particles: initialByRepeat[j], frameIndex: 0 }), stats = particleDistribution(r.metrics);
          const sample = { condition: i + 1, x, repeat: j + 1, seed: q.seed, p: q, initial: initialByRepeat[j], stats };
          samples.push(sample); sweepRawRows.push(sample); $('sweepProgress').value = sweepRawRows.length;
          await pause();
        }
        if (samples.length) {
          const aggregate = field => sampleStats(samples.map(s => s.stats[field].mean));
          sweepRows.push({ x, effectiveD: M.diffusion({ ...snapshot, [key]: x }), major: aggregate('major'), minor: aggregate('minor'), aspect: aggregate('aspect'), circularity: aggregate('circularity'), angle: axialStats(samples.flatMap(s => s.stats.angles)), attempted: samples.length, valid: samples.reduce((sum, s) => sum + s.stats.count, 0), total: snapshot.count * samples.length });
          updateSweepView();
        }
      }
    } catch (e) { failure = e.message; }
    finally {
      sweepRows.meta.status = failure ? 'failed' : sweepCancelRequested ? 'cancelled' : 'complete';
      sweepRows.meta.completedRepeats = sweepRawRows.length; sweepRows.meta.completedConditions = sweepRows.filter(r => r.attempted === repeats).length;
      $('sweepStatus').textContent = `${failure ? 'Calculation failed: ' + failure : sweepCancelRequested ? 'Canceled; completed results retained' : 'Completed'}. ${sweepRawRows.length}/${8 * repeats} repeats completed; ${sweepRows.meta.completedConditions}/8 conditions complete. Error bars show the sample SD across valid repeat means; SD cannot be estimated with fewer than two valid repeats.`;
      sweepBusy = false; $('runSweep').disabled = false; $('cancelSweep').disabled = true; $('exportSweep').disabled = !sweepRows.length; $('exportSweepRaw').disabled = !sweepRawRows.length;
      updateSweepView();
    }
  });
  function drawSweep() {
    const rows = sweepRows, meta = sweepRows.meta;
    function chart(id, fields, unit) {
      const W = 1000, H = 390, L = 65, R = 960, T = 30, B = 330;
      if (!rows.length) { $(id).innerHTML = '<text x="500" y="195" text-anchor="middle" fill="#a6b5a0" font-size="13">Run a parameter sweep to display means ± SD. Completed results are retained if the sweep is canceled.</text>'; return; }
      const max = Math.max(unit === 'µm' ? .1 : 1.1, ...rows.flatMap(r => fields.filter(([k]) => Number.isFinite(r[k].mean)).map(([k]) => r[k].mean + (r[k].sd ?? 0)))) * 1.12;
      const span = rows.at(-1).x - rows[0].x, X = x => span ? L + (x - rows[0].x) / span * (R - L) : (L + R) / 2, Y = y => B - y / max * (B - T);
      let svg = '';
      for (let i = 0; i <= 4; i++) { const y = max * i / 4; svg += `<path d="M${L},${Y(y)}H${R}" stroke="${colors.grid}"/><text x="${L - 13}" y="${Y(y) + 4}" fill="${colors.muted}" text-anchor="end">${fmt(y, 2)}${unit}</text>`; }
      for (const [key, color] of fields) {
        let path = '', open = false;
        rows.forEach(r => { const v = r[key]; if (!Number.isFinite(v.mean)) { open = false; return; } path += `${open ? 'L' : 'M'}${X(r.x)},${Y(v.mean)} `; open = true; });
        svg += `<path d="${path}" fill="none" stroke="${color}" stroke-width="2.5"/>`;
        rows.forEach(r => { const v = r[key]; if (!Number.isFinite(v.mean)) return;
          if (Number.isFinite(v.sd)) { const x = X(r.x), y1 = Y(Math.max(0, v.mean - v.sd)), y2 = Y(v.mean + v.sd); svg += `<path d="M${x},${y1}V${y2} M${x - 6},${y1}H${x + 6} M${x - 6},${y2}H${x + 6}" stroke="${color}" stroke-width="1.5"/>`; }
          svg += `<circle cx="${X(r.x)}" cy="${Y(v.mean)}" r="4" fill="${color}"><title>${r.x}: ${meanSD(v)} ${unit}; valid repeats ${v.n}/${r.attempted}</title></circle>`;
        });
      }
      rows.forEach(r => svg += `<text x="${X(r.x)}" y="${B + 25}" text-anchor="middle" fill="${colors.muted}">${r.x}</text>`);
      svg += `<text x="${R}" y="${H - 12}" text-anchor="end" fill="${colors.muted}">${meta.label}</text>`; $(id).innerHTML = svg;
    }
    chart('sweepChart', [['major', colors.teal], ['minor', colors.peach]], 'µm');
    chart('sweepAspectChart', [['aspect', colors.teal]], '');
    chart('sweepCircularityChart', [['circularity', colors.teal]], '');
  }
  function download(blob, name) {
    const a = document.createElement('a'), url = URL.createObjectURL(blob); a.href = url; a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(url), 3000); toast('Export file created.');
  }
  function csvDownload(rows, name) { const text = rows.map(row => row.map(v => { if (v === null || v === undefined) return ''; const value = String(v); return /[",\r\n]/.test(value) ? `"${value.replace(/"/g, '""')}"` : value; }).join(',')).join('\r\n'); download(new Blob(['\uFEFF' + text], { type: 'text/csv;charset=utf-8' }), name); }
  const environmentColumns = ['motion_dimensions', 'diffusion_model', 'temperature_C', 'water_viscosity_Pa_s', 'initial_z_std_um', 'random_xy', 'reference_z_um', 'between_line_channels', 'total_channels', 'single_channel_line_Hz', 'target_line_interval_s', 'effective_target_row_Hz', 'single_channel_line_time_s', 'frame_time_s', 'pixel_dwell_s'];
  const environmentValues = q => { const t = M.timing(q); return [q.motion3D ? 3 : 2, q.diffusionModel, q.temperatureC, M.waterViscosity(q.temperatureC), q.motion3D ? q.initialZStd : 0, q.randomXY, 0, q.betweenLineChannels || 0, (q.betweenLineChannels || 0) + 1, q.lineHz, t.targetLineTime, 1 / t.targetLineTime, t.lineTime, t.frameTime, t.dwell]; };
  function exportMetrics() {
    ensureResult();
    csvDownload([['particle_id', 'major_moment_um', 'minor_moment_um', 'aspect', 'angle_deg_image_clockwise', 'major_over_static', 'minor_over_static', 'threshold_area_um2', 'area_relative_error', 'valid', 'edge', 'overlap', 'pixels', 'frame', 'line_Hz', 'speed_um_s', 'angle_deg', 'effective_diffusion_um2_s', 'diameter_um', 'threshold', 'seed', 'mode', 'drift_x_um_s', 'drift_y_um_s', 'initial_z_um', 'final_z_um', ...environmentColumns, 'contour_major_um', 'contour_minor_um', 'contour_aspect', 'contour_circularity', 'contour_area_um2', 'contour_perimeter_um', 'contour_angle_deg_image_clockwise', 'contour_orientation_reliable', 'contour_center_x_um', 'contour_center_y_um'], ...result.metrics.map((m, k) => [m.id, m.major, m.minor, m.aspect, m.angle, m.majorRatio, m.minorRatio, m.area, m.areaError, m.valid, m.edge, m.overlap, m.pixels, result.frameIndex, p.lineHz, p.mode === 'brownian' ? 0 : p.speed, p.angle, M.diffusion(p), p.diameter, p.threshold, p.seed, p.mode, ...M.velocity(p), result.initial[k].z || 0, M.positionAt(result.paths[k], result.timing.frameTime).z || 0, ...environmentValues(p), m.contourMajor, m.contourMinor, m.contourAspect, m.contourCircularity, m.contourArea, m.contourPerimeter, m.contourAngle, m.contourOrientationReliable, m.contourX, m.contourY])], `confocal-particles-frame-${result.frameIndex}.csv`);
  }
  $('exportCSV').addEventListener('click', exportMetrics);
  $('exportSweep').addEventListener('click', () => {
    if (!sweepRows.length) { toast('Run a parameter sweep first.'); return; }
    const meta = sweepRows.meta;
    csvDownload([['condition_index', meta.parameter, 'contour_major_mean_of_repeat_means_um', 'contour_major_sd_across_repeat_means_um', 'contour_minor_mean_of_repeat_means_um', 'contour_minor_sd_across_repeat_means_um', 'contour_aspect_mean_of_repeat_means', 'contour_aspect_sd_across_repeat_means', 'contour_circularity_mean_of_repeat_means', 'contour_circularity_sd_across_repeat_means', 'valid_repeat_count', 'completed_repeat_count', 'requested_repeat_count', 'valid_particles', 'attempted_particles', 'all_repeats_axial_mean_deg', 'all_repeats_axial_circular_sd_deg', 'all_repeats_R2', 'direction_particle_count', 'base_seed', 'seed_step', 'run_status', 'effective_diffusion_um2_s', ...environmentColumns, 'parameters_json'], ...sweepRows.map((r, i) => { const q = { ...meta.p, [meta.parameter]: r.x }; return [i + 1, r.x, r.major.mean, r.major.sd, r.minor.mean, r.minor.sd, r.aspect.mean, r.aspect.sd, r.circularity.mean, r.circularity.sd, r.major.n, r.attempted, meta.repeats, r.valid, r.total, r.angle.mean, r.angle.sd, r.angle.resultant, r.angle.n, q.seed, meta.seedStep, meta.status, M.diffusion(q), ...environmentValues(q), JSON.stringify(q)]; })], 'confocal-parameter-sweep-summary.csv');
  });
  $('exportSweepRaw').addEventListener('click', () => {
    if (!sweepRawRows.length) { toast('There are no completed repeats to export.'); return; }
    const meta = sweepRows.meta;
    csvDownload([['condition_index', meta.parameter, 'repeat_index', 'seed', 'valid_particle_count', 'requested_particle_count', 'contour_major_mean_um', 'contour_major_sd_within_repeat_um', 'contour_minor_mean_um', 'contour_minor_sd_within_repeat_um', 'contour_aspect_mean', 'contour_aspect_sd_within_repeat', 'contour_circularity_mean', 'contour_circularity_sd_within_repeat', 'axial_direction_mean_deg', 'axial_circular_sd_deg', 'R2', 'mean_cos_2theta', 'mean_sin_2theta', 'direction_valid_count', 'near_circular_count', 'requested_repeats_per_condition', 'seed_step', 'run_status', 'effective_diffusion_um2_s', ...environmentColumns, 'parameters_json', 'initial_particles_json'], ...sweepRawRows.map(r => { const d = r.stats; return [r.condition, r.x, r.repeat, r.seed, d.count, r.p.count, d.major.mean, d.major.sd, d.minor.mean, d.minor.sd, d.aspect.mean, d.aspect.sd, d.circularity.mean, d.circularity.sd, d.angle.mean, d.angle.sd, d.angle.resultant, d.angle.cos2, d.angle.sin2, d.angle.n, d.nearCircular, meta.repeats, meta.seedStep, meta.status, M.diffusion(r.p), ...environmentValues(r.p), JSON.stringify(r.p), JSON.stringify(r.initial)]; })], 'confocal-parameter-sweep-repeats.csv');
  });
  $('exportOpen').addEventListener('click', () => { ensureResult(); $('exportDialog').showModal(); });
  $('exportDialog').addEventListener('click', e => { if (e.target === $('exportDialog')) $('exportDialog').close(); });
  document.querySelectorAll('[data-export]').forEach(b => b.addEventListener('click', () => {
    const type = b.dataset.export;
    if (type === 'metrics') exportMetrics();
    if (type === 'config') {
      const payload = { model: 'Confocal Motion Lab', version: '5.0.0', parameters: result.p, frameIndex: result.frameIndex,
        effectiveDiffusion_um2_s: M.diffusion(result.p), waterViscosity_Pa_s: M.waterViscosity(result.p.temperatureC),
        initialParticles: result.initial, timing: result.timing, baselineMomentDiameter_um: result.profile.baselineDiameter,
        baselineThresholdArea_um2: result.profile.baselineArea, metrics: result.metrics, particleDistribution: particleDistribution(result.metrics), contourCircularityMean: result.summary.contourCircularity, contourCircularitySD: result.summary.circularitySD,
        reproduction: 'ConfocalModel.simulate(parameters, {particles: initialParticles, frameIndex: frameIndex - 1})',
        definitions: { circularity: 'C=4*pi*A/P^2, where A and P are area and perimeter of the linearly interpolated outer threshold contour; dimensionless and sensitive to threshold and pixel resolution.', axes: '4*sqrt(eigenvalue) of intensity-weighted covariance above threshold, per-ID noiseless contribution', angle: 'degrees clockwise from image +x; [-90,90]; 180-degree-equivalent undirected principal axis', reference: 'stationary identical sphere centered at z=0, same PSF and absolute threshold; defocus and motion scan both contribute to ratios', contourAxes: 'linearly interpolated outer contour at the absolute threshold on each known particle noise-free signal; area, perimeter, moments, axes and aspect ratio use the same contour. Simulation uses isolated known-ID signals; experimental contours come from thresholded observed channels, so matching definitions do not make measurements identical. Orientation requires contourAspect>=1.05. Distribution SD is sample SD and is undefined for n<2.', betweenLines: 'After each target channel line, including the last, insert betweenLineChannels other channel line slots. Target row period=(1+x)/lineHz; frame=N*(1+x)/lineHz; pixel dwell=duty/(N*lineHz) unchanged. Brownian motion continues in all gaps. Bidirectional flips by target row, not by interleaved slot.', diffusion: 'Stokes-Einstein in bulk water: k_B*T/(3*pi*viscosity*diameter); each active axis variance=2*D*dt; 3D MSD=6*D*t', initialZ: 'normal distribution centered on focal plane with configured standard deviation; unbounded z Brownian motion', boundaries: 'open; no wrapping', noise: 'Poisson <=30 counts; Gaussian approximation >30 counts; background=2, read sigma=0.8 counts' } };
      download(new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' }),`confocal-experiment-frame-${result.frameIndex}.json`);
    }
    if (type === 'raw') {
      const n = result.p.resolution, rows = [['# model', 'Confocal Motion Lab 5.0.0'], ['# effective_diffusion_um2_s', M.diffusion(result.p)], ['# ' + environmentColumns.join(' / '), ...environmentValues(result.p)], ['# parameters_json', JSON.stringify(result.p)], ['# matrix_start'], ['y_um / x_um', ...Array.from({ length: n }, (_, x) => (x + .5) * result.timing.pixelSize)]];
      for (let y = 0; y < n; y++) rows.push([(y + .5) * result.timing.pixelSize, ...Array.from(result.image.slice(y * n, (y + 1) * n), v => v.toFixed(6))]);
      csvDownload(rows, `confocal-intensity-frame-${result.frameIndex}.csv`);
    }
    if (type === 'paths') {
      const rows = [['particle_id', 'time_s', 'x_um', 'y_um', 'z_um', 'relative_peak_signal', 'effective_diffusion_um2_s', 'frame', ...environmentColumns]];
      result.paths.forEach((path, k) => path.forEach(q => rows.push([result.initial[k].id, q.t, q.x, q.y, q.z || 0, M.sampleProfile(result.profile, 0, q.z || 0), M.diffusion(result.p), result.frameIndex, ...environmentValues(result.p)])));
      csvDownload(rows, `confocal-trajectories-frame-${result.frameIndex}.csv`);
    }
    if (type === 'comparison') exportComparison();
    $('exportDialog').close();
  }));
  function exportComparison() {
    const out = document.createElement('canvas'); out.width = 1600; out.height = 1200;
    const c = out.getContext('2d'); c.fillStyle = '#f7f8f4'; c.fillRect(0, 0, out.width, out.height);
    c.fillStyle = '#294c39'; c.font = '600 31px Arial, sans-serif'; c.fillText('Raster Lab · Particle Motion and Point-Scanning Imaging', 55, 63);
    c.fillStyle = '#7e9279'; c.font = '17px Arial, sans-serif'; c.fillText(`Frame ${result.frameIndex}  |  ${p.mode}  |  ${p.resolution}×${p.resolution} px  |  ${p.lineHz} Hz / ${fmt(result.timing.fps, 3)} fps  |  T=${fmt(result.timing.frameTime, 3)} s`, 55, 102);
    const truth = document.createElement('canvas'), scan = document.createElement('canvas'); truth.width = truth.height = scan.width = scan.height = 700;
    renderTruth(truth, .5); renderScan(scan, 1);
    c.font = '600 21px Arial, sans-serif'; c.fillStyle = '#34573d';
    c.fillText(`A  Instant snapshot · frame midpoint t=${fmt(result.timing.frameTime / 2, 3)} s`, 55, 155); c.fillText('B  Complete point-scanned image', 835, 155);
    c.drawImage(truth, 55, 180); c.drawImage(scan, 835, 180);
    c.font = '18px Arial, sans-serif'; c.fillStyle = '#536f50';
    c.fillText(`Diameter ${p.diameter} µm  |  drift: ${p.mode === 'brownian' ? 0 : p.speed} µm/s @ ${p.angle}°  |  D=${fmt(M.diffusion(p), 4)} µm²/s  |  FOV=${p.fov} µm  |  Seed=${p.seed}`, 55, 928);
    c.fillText(`Valid particles ${result.summary.count}/${p.count}  |  Optical-comparison major axis ${fmt(result.summary.majorRatio, 3)}×  |  minor axis ${fmt(result.summary.minorRatio, 3)}×  |  Area ${signed(result.summary.areaError)}`, 55, 965);
    c.fillText(`${p.motion3D ? '3D motion/xy optical sectioning' : 'Two-dimensional motion / z=0'}  |  ${p.diffusionModel === 'water' ? `In water ${p.temperatureC}°C / η=${fmt(M.waterViscosity(p.temperatureC) * 1000, 3)} mPa·s` : 'Manual D'}  |  Initial z SD ${p.motion3D ? p.initialZStd : 0} µm`, 55, 1002);
    c.fillText(`Between-line channels: ${p.betweenLineChannels || 0}  |  Target-line interval: ${fmt(result.timing.targetLineTime * 1000, 3)} ms  |  Pixel dwell: ${fmt(result.timing.dwell * 1e6, 3)} µs (unchanged by channel count)`, 55, 1039);
    const d = particleDistribution(result.metrics);
    c.fillText(`Per-particle contours: major axis ${meanSD(d.major)} µm  |  minor axis ${meanSD(d.minor)} µm  |  aspect ratio ${meanSD(d.aspect)}`, 55, 1076);
    c.font = '14px Arial, sans-serif'; c.fillStyle = '#9ca992';
    c.fillText(`Orientation: axial mean ${fmt(d.angle.mean, 1)}°  |  R₂=${fmt(d.angle.resultant, 3)}  |  axial circular SD=${fmt(d.angle.sd, 1)}°  |  valid N=${d.angle.n} (near-circular excluded: ${d.nearCircular})`, 55, 1120);
    c.fillText('Contour axes, area, perimeter and circularity use the linearly interpolated outer threshold contour. Circularity is C = 4πA/P². Values are mean ± sample SD; SD is unavailable for N < 2. Orientation is 180° periodic and clockwise from image +x.', 55, 1152);
    out.toBlob(blob => download(blob,`confocal-comparison-frame-${result.frameIndex}.png`), 'image/png');
  }
  syncControls(); compute(); drawSweep(); requestAnimationFrame(tick);
})();

