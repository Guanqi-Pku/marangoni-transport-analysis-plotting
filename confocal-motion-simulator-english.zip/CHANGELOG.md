# Changelog

## 5.0.0

- Added particle-level contour circularity, `C = 4πA/P²`, and included contour area and perimeter in particle exports.
- Added the circularity mean ± sample SD, per-particle distribution, and circularity summaries to parameter sweeps and exports.
- Replaced binary silhouette contour metrics with moments from the linearly interpolated outer threshold contour.
- Clarified that the simulator uses known-particle noise-free signals, while experimental contours are drawn from thresholded observed channels; matching formulas do not imply identical measurements.
- Retained the documented limitation that four-pass line averaging is not simulated.
