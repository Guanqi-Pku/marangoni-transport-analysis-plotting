const assert = require('node:assert/strict');
const { createHash } = require('node:crypto');
const M = require('./model.js');
let passed = 0;
function check(name, fn) { fn(); passed++; console.log('PASS ' + name); }
function near(actual, expected, tolerance, label) { assert.ok(Math.abs(actual - expected) <= tolerance, `${label}: ${actual} vs ${expected} ± ${tolerance}`); }
// Preserve the original 2-D directed-motion regressions explicitly even though
// the application's starting case is now 3-D diffusion in water.
const base = { ...M.defaults, noise: false, count: 1, diameter: 5, resolution: 256,
  mode: 'directed', motion3D: false, randomXY: false, diffusionModel: 'manual' };
check('line frequency, frame rate and pixel dwell have distinct correct units', () => {
  const t = M.timing(base); near(t.frameTime, 1.28, 1e-12, 'frame s'); near(t.fps, .78125, 1e-12, 'fps'); near(t.dwell * 1e6, 15.625, 1e-10, 'dwell µs');
});
check('stationary raster equals simultaneous optical image pixel for pixel', () => {
  const r = M.simulate({ ...base, speed: 0 }); assert.deepEqual(r.ideal, r.stationary); assert.deepEqual(r.image, r.ideal);
  near(r.summary.majorRatio, 1, .015, 'major'); near(r.summary.minorRatio, 1, .015, 'minor'); near(r.summary.areaError, 0, .02, 'area');
});
check('same slow-axis direction elongates by 1/(1-v/u)', () => {
  const r = M.simulate({ ...base, speed: 8, angle: 90 });
  near(r.summary.majorRatio, 1 / (1 - 8 / 31.25), .015, 'stretch'); near(r.summary.minorRatio, 1, .015, 'transverse');
});
check('opposite slow-axis direction compresses by 1/(1+v/u)', () => {
  const r = M.simulate({ ...base, speed: 8, angle: 270 });
  near(r.summary.minorRatio, 1 / (1 + 8 / 31.25), .015, 'compression'); near(r.summary.majorRatio, 1, .015, 'transverse');
});
check('oblique-motion measured axes agree with full affine singular values', () => {
  const r = M.simulate({ ...base, speed: 9, angle: 60 });
  near(r.summary.majorRatio, r.theory.majorRatio, .015, 'major'); near(r.summary.minorRatio, r.theory.minorRatio, .015, 'minor');
  near(r.summary.areaError + 1, r.theory.areaRatio, .025, 'area');
});
check('reversing scan direction reverses stretch/compression relation', () => {
  const r = M.simulate({ ...base, speed: 8, angle: 270, slowDirection: -1, fastDirection: -1 });
  near(r.summary.majorRatio, 1 / (1 - 8 / 31.25), .02, 'reverse stretch');
});
check('bidirectional static data are identical; affine theory disabled', () => {
  const r = M.simulate({ ...base, speed: 0, bidirectional: true }); assert.deepEqual(r.ideal, r.stationary); assert.equal(r.theory.applicable, false);
});
check('higher line frequency reduces directional distortion', () => {
  const a = M.simulate({ ...base, speed: 8, angle: 90, lineHz: 200 });
  const b = M.simulate({ ...base, speed: 8, angle: 90, lineHz: 800 }); assert.ok(b.summary.majorRatio < a.summary.majorRatio);
});
check('optical profile is finite, normalized and radially decays', () => {
  for (const diameter of [.5, 4, 15]) {
    const pr = M.makeProfile({ ...base, diameter }); near(pr.values[0], 1, 1e-12, 'peak');
    assert.ok(Number.isFinite(pr.baselineDiameter)); assert.ok(pr.values.at(-1) < 1e-4);
    for (let i = 1; i < pr.values.length; i++) assert.ok(pr.values[i] <= pr.values[i - 1] + 1e-6);
  }
});
check('Brownian acquisition and display noise reproduce with same seed', () => {
  const p = { ...base, mode: 'mixed', diffusion: .5, noise: true, resolution: 64 };
  const a = M.simulate(p), b = M.simulate(p); assert.deepEqual(a.image, b.image); assert.deepEqual(a.final, b.final);
  const c = M.simulate({ ...p, seed: 43 }); assert.notDeepEqual(a.image, c.image);
});
check('Brownian endpoints obey 2-D ensemble MSD = 4DT', () => {
  let squared = 0, dxMean = 0, count = 0;
  const p = { ...base, mode: 'brownian', speed: 0, diffusion: 2, count: 25, resolution: 16 };
  for (let seed = 1; seed <= 45; seed++) {
    const r = M.simulate({ ...p, seed });
    r.final.forEach((q, k) => { const dx = q.x - r.initial[k].x, dy = q.y - r.initial[k].y; squared += dx * dx + dy * dy; dxMean += dx; count++; });
  }
  const expected = 4 * p.diffusion * M.timing(p).frameTime;
  near(squared / count, expected, expected * .10, 'MSD'); near(dxMean / count, 0, .04, 'drift');
});
check('noise affects rendered data but not per-ID shape measurement', () => {
  const a = M.simulate({ ...base, noise: true }), b = M.simulate(base);
  assert.deepEqual(a.metrics, b.metrics); assert.notDeepEqual(a.image, b.image); assert.deepEqual(a.ideal, b.ideal);
});
check('successive frames continue positions and export initialization reproduces them', () => {
  const p = { ...base, mode: 'mixed', diffusion: .3, resolution: 64 };
  const a = M.simulate(p), b = M.simulate(p, a.continuation); assert.deepEqual(b.initial, a.final); assert.equal(b.frameIndex, 2);
  const replay = M.simulate(p, { particles: b.initial, frameIndex: b.frameIndex - 1 }); assert.deepEqual(replay.image, b.image);
});
check('clipped and overlapping particles are excluded from aggregate', () => {
  const p = { ...base, count: 2, speed: 0 };
  const r = M.simulate(p, { frameIndex: 0, particles: [{ id: 1, x: 20, y: 20 }, { id: 2, x: 20, y: 20 }] });
  assert.equal(r.summary.count, 0); assert.equal(r.summary.majorRatio, null); assert.ok(r.metrics.every(m => m.overlap));
  const edge = M.simulate({ ...p, count: 1 }, { frameIndex: 0, particles: [{ id: 1, x: 0, y: 20 }] }); assert.equal(edge.summary.count, 0); assert.ok(edge.metrics[0].edge);
});
check('3-point dwell integration recovers identical static image', () => {
  const a = M.simulate({ ...base, speed: 0 }), b = M.simulate({ ...base, speed: 0, dwellSamples: 3 });
  assert.deepEqual(a.image, b.image);
});
check('water Stokes–Einstein diffusion uses SI viscosity and inverse diameter', () => {
  near(M.waterViscosity(25), .00089044, 1e-7, 'water viscosity Pa s');
  near(M.stokesEinstein(2.5, 25), .1962017, 1e-6, 'D µm²/s');
  near(M.stokesEinstein(1.25, 25), 2 * M.stokesEinstein(2.5, 25), 1e-12, 'inverse diameter');
  assert.ok(M.stokesEinstein(2.5, 40) > M.stokesEinstein(2.5, 25));
  near(M.diffusion({ ...M.defaults, diameter: 5 }), .09810085, 1e-6, 'automatic D');
  near(M.diffusion({ ...M.defaults, diffusionModel: 'manual', diffusion: .7 }), .7, 0, 'manual override');
  assert.equal(M.diffusion({ ...M.defaults, mode: 'directed' }), 0);
});
check('3-D Brownian ensemble obeys independent per-axis 2DT and total 6DT', () => {
  const p = { ...M.defaults, noise: false, count: 40, resolution: 16, mode: 'mixed',
    speed: .4, diameter: 2.5, initialZStd: .5, motion3D: true, diffusionModel: 'water' };
  const t = M.timing(p).frameTime, expected = 2 * M.diffusion(p) * t;
  const sum = [0, 0, 0], squared = [0, 0, 0], cross = [0, 0, 0]; let count = 0;
  for (let seed = 1; seed <= 80; seed++) {
    const r = M.simulate({ ...p, seed });
    r.final.forEach((q, k) => {
      const a = r.initial[k], v = [q.x - a.x - p.speed * t, q.y - a.y, q.z - a.z];
      v.forEach((d, axis) => { sum[axis] += d; squared[axis] += d * d; });
      cross[0] += v[0] * v[1]; cross[1] += v[0] * v[2]; cross[2] += v[1] * v[2]; count++;
    });
  }
  squared.forEach((v, axis) => near(v / count, expected, expected * .07, 'axis ' + axis + ' MSD'));
  sum.forEach(v => near(v / count, 0, Math.sqrt(expected) * .055, 'zero residual mean'));
  cross.forEach(v => near(v / count, 0, expected * .06, 'independent increments'));
  near(squared.reduce((a, b) => a + b, 0) / count, 3 * expected, 3 * expected * .05, '3-D MSD');
});
check('random initialization is reproducible, near focus, and avoids initial xy overlap', () => {
  const p = { ...M.defaults, count: 80, fov: 90, initialZStd: .5 };
  const a = M.createParticles(p); assert.deepEqual(a, M.createParticles(p));
  const variance = a.reduce((s, q) => s + q.z * q.z, 0) / a.length;
  near(variance, p.initialZStd ** 2, .09, 'initial z variance');
  for (let i = 0; i < a.length; i++) for (let j = 0; j < i; j++) {
    assert.ok(Math.hypot(a[i].x - a[j].x, a[i].y - a[j].y) >= p.diameter + p.psfXY - 1e-10);
  }
  assert.ok(M.createParticles({ ...p, motion3D: false }).every(q => q.z === 0));
});
check('defocus dims and shrinks sphere images without renormalizing each z plane', () => {
  for (const diameter of [.2, .5, 2.5, 5]) {
    const profile = M.makeProfile({ ...M.defaults, diameter });
    near(M.sampleProfile(profile, 0, 0), 1, 1e-12, 'common focal peak');
    const z = Math.max(diameter / 2 + .25, M.defaults.psfZ), off = M.sampleProfile(profile, 0, z);
    assert.ok(off > 0 && off < .6, 'axial attenuation: ' + diameter + ' / ' + off);
    near(off, M.sampleProfile(profile, 0, -z), 1e-12, 'z symmetry');
    assert.equal(M.sampleProfile(profile, 0, profile.zExtent + 1), 0);
  }
  const profile = M.makeProfile(M.defaults);
  const thresholdRadius = z => {
    let outer = 0;
    for (let r = 0; r <= profile.extent; r += profile.dx / 2) if (M.sampleProfile(profile, r, z) >= .35) outer = r;
    return outer;
  };
  assert.ok(thresholdRadius(1.1) < thresholdRadius(0) * .85);
  assert.strictEqual(M.makeProfile({ ...M.defaults }), profile, 'reuse optical lookup');
});
check('stationary defocused particle uses its initial z in scan and reference image', () => {
  const p = { ...M.defaults, noise: false, mode: 'directed', speed: 0, count: 1, resolution: 128 };
  const a = M.simulate(p, { frameIndex: 0, particles: [{ id: 1, x: 20, y: 20, z: 1.1 }] });
  const b = M.simulate(p, { frameIndex: 0, particles: [{ id: 1, x: 20, y: 20, z: 0 }] });
  assert.deepEqual(a.ideal, a.stationary);
  assert.ok(Math.max(...a.ideal) < Math.max(...b.ideal));
  assert.ok(a.metrics[0].major < b.metrics[0].major);
  assert.equal(a.metrics[0].initialZ, 1.1); assert.equal(a.metrics[0].finalZ, 1.1);
  assert.equal(a.theory.applicable, false);
});
check('3-D continuation preserves z and complete stochastic replay', () => {
  const p = { ...M.defaults, count: 3, resolution: 32 };
  const a = M.simulate(p), b = M.simulate(p, a.continuation);
  assert.deepEqual(b.initial, a.final); assert.ok(b.final.some((q, k) => q.z !== b.initial[k].z));
  const replay = M.simulate(p, { particles: b.initial, frameIndex: b.frameIndex - 1 });
  assert.deepEqual(replay.image, b.image); assert.deepEqual(replay.final, b.final); assert.deepEqual(replay.paths, b.paths);
  const q = M.positionAt(b.paths[0], b.timing.frameTime);
  near(q.z, b.final[0].z, 1e-12, 'playback z');
  const mid = M.positionAt([{ t: 0, x: 0, y: 0, z: -1 }, { t: 2, x: 2, y: 4, z: 3 }], 1);
  assert.deepEqual(mid, { x: 1, y: 2, z: 1 });
});
check('matched seeds give identical xy motion for paired 2-D and 3-D comparisons', () => {
  const p = { ...M.defaults, count: 5, resolution: 32, noise: false };
  const a = M.simulate(p), b = M.simulate({ ...p, motion3D: false });
  const xyOnly = paths => paths.map(path => path.map(({ t, x, y }) => ({ t, x, y })));
  assert.deepEqual(xyOnly(a.paths), xyOnly(b.paths));
  assert.ok(a.paths.some(path => path.some(q => q.z !== 0)));
  assert.ok(b.paths.every(path => path.every(q => q.z === 0)));
});
check('motion remains unbounded rather than wrapping or reflecting at image edges', () => {
  const r = M.simulate({ ...base, speed: 100, angle: 0 }, {
    frameIndex: 0, particles: [{ id: 1, x: 39, y: 20, z: 0 }] });
  near(r.final[0].x, 39 + 100 * r.timing.frameTime, 1e-9, 'unbounded x');
});
check('zero intervening channels preserves pre-upgrade pixels exactly', () => {
  const cases = [
    [{ ...M.defaults, resolution: 64, count: 3 }, '5c5b8d03c961fb962f7babfb0d2051cd8a1c4d9f566898ffe12214e4d6b06ccf',
      '679052eb7d83b36e8bcf1ef63f3a0694d6c47288897368e8172e4294ddc346f0'],
    [{ ...M.defaults, resolution: 64, count: 1, mode: 'directed', motion3D: false,
      randomXY: false, diameter: 5, speed: 9, angle: 60 }, 'fd91101ff5a9711fdbfa8d111e79772abef1dbb2b7b009f9ae53ecd4e3255f99',
      '3380d0906605241dac7df337edd0763284e979476fe013dab7ede7b3582cbeea']
  ];
  for (const [p, expected, expectedMotion] of cases) {
    const r = M.simulate({ ...p, betweenLineChannels: 0 });
    const hash = createHash('sha256').update(Buffer.from(r.image.buffer)).update(Buffer.from(r.ideal.buffer))
      .update(Buffer.from(r.stationary.buffer)).digest('hex');
    assert.equal(hash, expected);
    assert.equal(createHash('sha256').update(JSON.stringify({ initial: r.initial, final: r.final, paths: r.paths })).digest('hex'), expectedMotion);
  }
});
check('interleaved channels increase target row interval and full frame while retaining dwell', () => {
  const t0 = M.timing(base);
  for (const x of [0, 1, 2]) {
    const p = { ...base, betweenLineChannels: x }, t = M.timing(p);
    near(t.lineTime, 1 / p.lineHz, 1e-14, 'per-channel line time');
    near(t.targetLineTime, (x + 1) / p.lineHz, 1e-14, 'target interval');
    near(t.frameTime, (x + 1) * t0.frameTime, 1e-14, 'full regular frame period');
    near(t.dwell, t0.dwell, 1e-14, 'constant pixel dwell');
    near(t.fastSpeed, t0.fastSpeed, 1e-12, 'constant fast speed');
    near(t.slowSpeed, t0.slowSpeed / (x + 1), 1e-12, 'effective slow speed');
    assert.equal(t.channelCount, x + 1); assert.equal(t.betweenLineChannels, x);
    const r = M.simulate({ ...p, resolution: 16, speed: .4, angle: 0 });
    const n = r.p.resolution, stride = Math.floor(n / 8), perRow = Math.ceil(n / stride);
    for (let row = 0; row < n; row++) {
      const first = r.paths[0][1 + row * perRow].t;
      near(first, row * r.timing.targetLineTime + r.timing.dwell / 2, 1e-13, 'first target sample');
    }
    near(r.paths[0].at(-1).t, r.timing.frameTime, 1e-13, 'endpoint includes final other-channel slots');
  }
});
check('acquisition phase distinguishes target scanning, turnaround and other-channel slots', () => {
  const p = { ...base, resolution: 4, lineHz: 100, duty: .8, betweenLineChannels: 2, bidirectional: true };
  let q = M.acquisitionPhase(p, .004);
  assert.equal(q.phase, 'target-scan'); assert.equal(q.pixelsInRow, 2); assert.equal(q.acquiredPixels, 2);
  assert.equal(q.completedRows, 0); assert.equal(q.fastDirection, 1);
  q = M.acquisitionPhase(p, .009);
  assert.equal(q.phase, 'target-turnaround'); assert.equal(q.completedRows, 1); assert.equal(q.acquiredPixels, 4);
  assert.equal(q.pixelsInRow, 0); assert.equal(q.targetActive, false);
  q = M.acquisitionPhase(p, .014);
  assert.equal(q.phase, 'other-scan'); assert.equal(q.slotIndex, 1); assert.equal(q.completedRows, 1);
  assert.equal(q.pixelsInRow, 0); assert.equal(q.acquiredPixels, 4);
  q = M.acquisitionPhase(p, .029);
  assert.equal(q.phase, 'other-turnaround'); assert.equal(q.slotIndex, 2); assert.equal(q.acquiredPixels, 4);
  q = M.acquisitionPhase(p, .034);
  assert.equal(q.targetRow, 1); assert.equal(q.fastDirection, -1); assert.equal(q.completedRows, 1); assert.equal(q.acquiredPixels, 6);
  assert.equal(M.acquisitionPhase({ ...p, slowDirection: -1 }, .034).rowIndex, 2);
  q = M.acquisitionPhase(p, M.timing(p).frameTime);
  assert.equal(q.phase, 'complete'); assert.equal(q.completedRows, 4); assert.equal(q.acquiredPixels, 16); assert.equal(q.pixelsInRow, 0);
  for (const x of [0, 1, 2]) {
    const p = { ...M.defaults, betweenLineChannels: x }, t = M.timing(p);
    for (let row = 0; row < p.resolution; row++) {
      const atStart = M.acquisitionPhase(p, row * t.targetLineTime);
      assert.equal(atStart.targetRow, row); assert.equal(atStart.slot, 'target'); assert.equal(atStart.completedRows, row);
      const atTurn = M.acquisitionPhase(p, row * t.targetLineTime + p.duty * t.lineTime);
      assert.equal(atTurn.completedRows, row + 1); assert.equal(atTurn.pixelsInRow, 0);
    }
  }
});
check('interleaved deterministic scans have stronger distortion predicted by effective slow speed', () => {
  let previous = 0;
  for (const x of [0, 1, 2]) {
    const p = { ...base, betweenLineChannels: x, speed: 3, angle: 90 };
    const r = M.simulate(p), expected = 1 / (1 - p.speed / r.timing.slowSpeed);
    near(r.summary.majorRatio, expected, .02, 'interleaved elongation');
    // The full affine model additionally retains the very small fast-axis shear.
    near(r.theory.majorRatio, expected, 1e-6, 'affine target time prediction');
    assert.ok(r.summary.majorRatio > previous); previous = r.summary.majorRatio;
  }
});
check('movement continues across omitted channel slots and final frame gap', () => {
  const p = { ...base, resolution: 16, speed: 1, angle: 0, betweenLineChannels: 2 };
  const a = M.simulate(p), path = a.paths[0];
  // For n=16 the eight records per row are cols 0,2,...14. These records
  // span the two other-channel slots before the next target row's col 0.
  const before = path[8], after = path[9];
  assert.ok(after.t - before.t > 2 / p.lineHz);
  near(after.x - before.x, p.speed * (after.t - before.t), 1e-12, 'drift during gap');
  near(a.final[0].x - a.initial[0].x, p.speed * a.timing.frameTime, 1e-10, 'full-period drift');
  const b = M.simulate(p, a.continuation); assert.deepEqual(b.initial, a.final);
  assert.equal(b.paths[0][0].t, 0);
});
check('three-dimensional diffusion MSD uses the full multichannel frame period', () => {
  for (const x of [1, 2]) {
    const p = { ...M.defaults, resolution: 8, count: 30, noise: false, betweenLineChannels: x, mode: 'brownian' };
    const expected = 6 * M.diffusion(p) * M.timing(p).frameTime; let total = 0, count = 0;
    for (let seed = 1; seed <= 60; seed++) {
      const r = M.simulate({ ...p, seed });
      r.final.forEach((q, k) => { const a = r.initial[k]; total += (q.x - a.x) ** 2 + (q.y - a.y) ** 2 + (q.z - a.z) ** 2; count++; });
    }
    near(total / count, expected, expected * .06, 'full-frame 3-D MSD x=' + x);
    const a = M.simulate(p), b = M.simulate(p, a.continuation);
    const replay = M.simulate(p, { particles: b.initial, frameIndex: b.frameIndex - 1 });
    assert.deepEqual(b.initial, a.final); assert.deepEqual(b.final, replay.final); assert.deepEqual(b.image, replay.image);
  }
});
function rectangleMask(n, x, y, w, h) {
  const mask = new Uint8Array(n * n);
  for (let j = y; j < y + h; j++) for (let i = x; i < x + w; i++) mask[j * n + i] = 1;
  return mask;
}
check('individual binary contour axes use physical size and exact filled-cell area moments', () => {
  const n = 64, a = rectangleMask(n, 5, 7, 10, 4), b = rectangleMask(n, 20, 30, 20, 8);
  const m = M.binaryContourEllipse(a, n, .5), mm = M.binaryContourEllipse(b, n, .5);
  near(m.x, 5, 1e-12, 'binary area x centroid µm'); near(m.y, 4.5, 1e-12, 'binary area y centroid µm');
  near(m.area, 10, 1e-12, 'area µm²');
  near(m.covariance.xx, 25 / 12, 1e-12, 'full square-cell xx variance µm²');
  near(m.covariance.yy, 4 / 12, 1e-12, 'full square-cell yy variance µm²');
  near(m.major, 4 * Math.sqrt(25 / 12), 1e-12, 'physical major axis µm');
  near(m.minor, 4 * Math.sqrt(4 / 12), 1e-12, 'physical minor axis µm');
  near(m.aspect, 2.5, 1e-12, 'rectangle aspect'); near(m.angle, 0, 1e-10, 'horizontal orientation');
  near(mm.major, 2 * m.major, 1e-12, 'doubling physical width doubles measured major');
  near(mm.minor, 2 * m.minor, 1e-12, 'doubling physical height doubles measured minor');
  assert.equal(m.orientationReliable, true);
});
check('individual binary contours preserve signed directions and flag circles', () => {
  const n = 201;
  for (const angle of [-30, 30]) {
    const mask = new Uint8Array(n * n), a = angle * Math.PI / 180, c = Math.cos(a), s = Math.sin(a);
    for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
      const xx = (x - 100) * c + (y - 100) * s, yy = -(x - 100) * s + (y - 100) * c;
      if ((xx / 60) ** 2 + (yy / 25) ** 2 <= 1) mask[y * n + x] = 1;
    }
    const m = M.binaryContourEllipse(mask, n, .2);
    near(m.major, 24, .06, 'ellipse major µm'); near(m.minor, 10, .04, 'ellipse minor µm');
    near(m.angle, angle, .15, 'clockwise image+x signed direction'); assert.equal(m.orientationReliable, true);
  }
  const mask = new Uint8Array(n * n);
  for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) if ((x - 100) ** 2 + (y - 100) ** 2 <= 45 ** 2) mask[y * n + x] = 1;
  const circle = M.binaryContourEllipse(mask, n, .2);
  near(circle.major, 18, .01, 'circle diameter µm'); near(circle.aspect, 1, 1e-12, 'circle aspect');
  assert.equal(circle.orientationReliable, false); assert.equal(M.binaryContourEllipse(new Uint8Array(n * n), n), null);
});
check('per-ID contour metrics agree with interpolated scalar contour and ignore display noise', () => {
  const p = { ...base, resolution: 128, diameter: 4, speed: 0 }, initial = { frameIndex: 0, particles: [{ id: 1, x: 20, y: 20 }] };
  const a = M.simulate(p, initial), b = M.simulate({ ...p, noise: true }, initial);
  const expected = M.intensityContourMetrics(a.ideal, p.resolution, p.resolution, p.threshold, p.fov / p.resolution, .5, .5);
  const m = a.metrics[0]; assert.equal(m.valid, true); assert.deepEqual(a.metrics, b.metrics);
  for (const key of ['Major', 'Minor', 'Aspect', 'X', 'Y', 'Circularity', 'Area', 'Perimeter'])
    near(m['contour' + key], expected[key[0].toLowerCase() + key.slice(1)], 2e-7, 'per-ID contour ' + key);
  near(a.summary.contourMajor, m.contourMajor, 1e-12, 'single-ID mean');
  assert.ok(m.contourMajor > m.major, 'outer contour and intensity weighted diameters remain separate');
  near(a.summary.circularity, m.contourCircularity, 1e-12, 'single-ID circularity mean');
  assert.equal(a.summary.circularitySD, null);
  assert.equal(m.contourOrientationReliable, false);
});
check('contour summary includes only valid IDs and missing contours have null measurements', () => {
  const p = { ...base, resolution: 64, count: 2, diameter: 4, speed: 0 };
  const r = M.simulate(p, { frameIndex: 0, particles: [{ id: 1, x: 0, y: 20 }, { id: 2, x: 28, y: 20 }] });
  assert.equal(r.summary.count, 1); assert.equal(r.metrics[0].valid, false); assert.equal(r.metrics[0].contourOrientationReliable, false);
  near(r.summary.contourMajor, r.metrics[1].contourMajor, 1e-12, 'valid-only contour major');
  near(r.summary.contourMinor, r.metrics[1].contourMinor, 1e-12, 'valid-only contour minor');
  const same = M.simulate(p, { frameIndex: 0, particles: [{ id: 1, x: 20, y: 20 }, { id: 2, x: 20, y: 20 }] });
  assert.equal(same.summary.count, 0); assert.equal(same.summary.contourAspect, null);
  assert.ok(same.metrics.every(m => !m.valid && !m.contourOrientationReliable));
  const missing = M.simulate({ ...p, count: 1, resolution: 16, diameter: .2 }, { frameIndex: 0, particles: [{ id: 1, x: 20, y: 20 }] });
  assert.equal(missing.metrics[0].missing, true); assert.equal(missing.metrics[0].contourMajor, null);
  assert.equal(missing.metrics[0].contourMinor, null); assert.equal(missing.metrics[0].contourAngle, null);
  assert.equal(missing.metrics[0].contourOrientationReliable, false);
});
check('interpolated circularity recovers sampled circle geometry and is scale invariant', () => {
  const n = 121, image = new Float64Array(n * n);
  for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) image[y * n + x] = Math.exp(-((x - 59.23) ** 2 + (y - 60.71) ** 2) / (2 * 12 ** 2));
  const a = M.intensityContourMetrics(image, n, n, .5), b = M.intensityContourMetrics(image, n, n, .5, .4456);
  near(a.circularity, 1, .001, 'resolved sampled circle C'); near(a.aspect, 1, .001, 'circle a/b');
  near(a.major, 24 * Math.sqrt(2 * Math.log(2)), .03, 'Gaussian half maximum diameter');
  near(a.circularity, b.circularity, 1e-14, 'C independent of calibration'); near(b.major, a.major * .4456, 1e-12, 'physical axis scaling');
});
check('diagonal high connectivity and holes match outer-contour convention', () => {
  const n = 9, image = new Float64Array(n * n); image[3 * n + 3] = image[4 * n + 4] = 1;
  const diagonal = M.intensityContourMetrics(image, n, n, .5); assert.equal(diagonal.closedContourCount, 1);
  near(diagonal.area, 1.5, 1e-14, 'connected diagonal outer area');
  const ring = new Float64Array(21 * 21), disk = new Float64Array(21 * 21);
  for (let y = 0; y < 21; y++) for (let x = 0; x < 21; x++) { const r = Math.hypot(x - 10, y - 10); if (r <= 7) disk[y * 21 + x] = 1; if (r <= 7 && r >= 3) ring[y * 21 + x] = 1; }
  const a = M.intensityContourMetrics(ring, 21, 21, .5), b = M.intensityContourMetrics(disk, 21, 21, .5);
  assert.equal(a.closedContourCount, 2); near(a.area, b.area, 1e-14, 'ignore hole for outer area'); near(a.circularity, b.circularity, 1e-14, 'outer C');
  assert.equal(M.intensityContourMetrics(new Float64Array(81), 9, 9, .5), null);
});
console.log(`\n${passed} physical and reproducibility checks passed.`);
